<?php
/**
 * Page fixes (paid packages): description for search, image descriptions, main heading, questions and answers.
 *
 * "Landing page" package: one page, chosen by the site owner (default: the home page), changeable any time.
 * "Whole site" package: every published page (the all-pages table lives in includes/site).
 *
 * Rules (decided 9.11.2026):
 * - Lift never changes the page's texts or design. Image descriptions are added only while the page is shown,
 *   to images that have none; deleting Lift returns the page exactly as it was.
 * - Description for search: with Yoast or Rank Math it is saved in THEIR field, and only when that field is empty.
 *   With All in One SEO Lift only explains. Without an SEO plugin Lift adds the description itself.
 * - Main heading: Lift only explains and links to the page editor.
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Page fixes feature.
 */
class Page_Fixes {

	const OPTION_PAGE = 'zarmumia_lift_page';          // Landing package: the chosen page ID.
	const META_SCAN   = '_zarmumia_lift_scan';         // Last check of a page.
	const META_DESC   = '_zarmumia_lift_description';  // Lift's own description (no SEO plugin).
	const META_ALTS   = '_zarmumia_lift_alts';         // [ image address => description ].
	const ACTION      = 'zarmumia_lift_page_fix';
	const ANCHOR      = 'zarmumia-lift-fixes';
	const MAX_DESC    = 300;
	const MAX_ALT     = 250;

	/**
	 * Secret download folder of the Landing page package on zarmumia.co.il (update by click). Only in the paid files.
	 */
	const DOWNLOADS = '58164358bfc6';

	/**
	 * Checks that have a fix in the "Fixes for this page" panel.
	 */
	const FIX_IDS = array( 'description', 'alt', 'h1', 'faq' );

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		if ( is_admin() ) {
			add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_action' ) );
			return;
		}
		add_filter( 'wp_content_img_tag', array( __CLASS__, 'add_alts' ), 20 ); // Images in the page content (also Elementor).
		add_filter( 'render_block', array( __CLASS__, 'add_alts' ), 20 );      // Images in blocks and block-theme parts.
		add_action( 'wp_head', array( __CLASS__, 'output_description' ), 2 );
	}

	/**
	 * Landing package: the chosen page. Default: the home page, when it is a page.
	 *
	 * @return int 0 when none.
	 */
	public static function chosen() {
		$id = (int) get_option( self::OPTION_PAGE, 0 );
		if ( $id && 'publish' === get_post_status( $id ) && 'page' === get_post_type( $id ) ) {
			return $id;
		}
		return self::front_id();
	}

	/**
	 * The home page ID when the home page is a page, else 0.
	 *
	 * @return int
	 */
	public static function front_id() {
		return 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
	}

	/**
	 * The page the main readiness score checks: the chosen page (landing), else the home page.
	 *
	 * @return int 0 = the home page that is not a page (latest posts).
	 */
	public static function main_id() {
		return ZARMUMIA_LIFT_SITE ? self::front_id() : self::chosen();
	}

	/**
	 * May Lift check and fix this page in this package?
	 *
	 * @param int $id Page ID.
	 * @return bool
	 */
	public static function allowed( $id ) {
		$id = (int) $id;
		if ( ! $id || 'page' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) {
			return false;
		}
		return ZARMUMIA_LIFT_SITE || self::chosen() === $id;
	}

	/**
	 * Published pages, for the page choice.
	 *
	 * @return \WP_Post[]
	 */
	public static function pages() {
		return get_pages(
			array(
				'post_status' => 'publish',
				'sort_column' => 'menu_order,post_title',
				'number'      => 300,
			)
		);
	}

	/**
	 * The page shown on the front end right now, if Lift may fix it.
	 *
	 * @return int 0 when not.
	 */
	private static function current_id() {
		if ( ! is_singular( 'page' ) ) {
			return 0;
		}
		$id = (int) get_queried_object_id();
		return self::allowed( $id ) ? $id : 0;
	}

	/**
	 * The owner's image descriptions for a page.
	 *
	 * @param int $id Page ID.
	 * @return array [ image address => description ]
	 */
	private static function alts( $id ) {
		$alts = get_post_meta( $id, self::META_ALTS, true );
		return is_array( $alts ) ? array_filter( $alts, 'is_string' ) : array();
	}

	/**
	 * Add the owner's image descriptions, only to images that have none. Nothing is saved in the page.
	 *
	 * @param string $html HTML of one image or one block.
	 * @return string
	 */
	public static function add_alts( $html ) {
		if ( ! is_string( $html ) || false === stripos( $html, '<img' ) || ! class_exists( '\WP_HTML_Tag_Processor' ) ) {
			return $html;
		}
		static $alts = null;
		if ( null === $alts ) {
			$id   = self::current_id();
			$alts = $id ? self::alts( $id ) : array();
		}
		if ( ! $alts ) {
			return $html;
		}
		$tags = new \WP_HTML_Tag_Processor( $html );
		while ( $tags->next_tag( 'img' ) ) {
			$alt = $tags->get_attribute( 'alt' );
			if ( is_string( $alt ) && '' !== trim( $alt ) ) {
				continue; // Never replace a description that exists.
			}
			// Lazy-loaded images: the real address in a data- attribute first (the same way the check reads them), then src.
			foreach ( array_merge( Readiness::LAZY_ATTRS, array( 'src' ) ) as $attr ) {
				$src = (string) $tags->get_attribute( $attr );
				if ( '' !== $src && isset( $alts[ $src ] ) ) {
					$tags->set_attribute( 'alt', $alts[ $src ] );
					break;
				}
			}
		}
		return $tags->get_updated_html();
	}

	/**
	 * Who keeps the description for search on this site.
	 *
	 * @return string yoast | rankmath | aioseo | lift
	 */
	public static function description_owner() {
		if ( defined( 'WPSEO_VERSION' ) ) {
			return 'yoast';
		}
		if ( Robots::rank_math_ready() ) {
			return 'rankmath';
		}
		if ( defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' ) ) {
			return 'aioseo';
		}
		return 'lift';
	}

	/**
	 * Post meta key of the SEO plugin's description field (Yoast, Rank Math) or Lift's own.
	 *
	 * @return string Empty for All in One SEO (its own table; Lift only explains).
	 */
	private static function description_key() {
		$keys = array(
			'yoast'    => '_yoast_wpseo_metadesc',
			'rankmath' => 'rank_math_description',
			'aioseo'   => '',
			'lift'     => self::META_DESC,
		);
		return $keys[ self::description_owner() ];
	}

	/**
	 * No SEO plugin: Lift's own description on the pages it may fix.
	 */
	public static function output_description() {
		if ( 'lift' !== self::description_owner() ) {
			return;
		}
		$id   = self::current_id();
		$desc = $id ? self::lift_description( $id ) : '';
		if ( '' !== $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '" />' . "\n";
		}
	}

	/**
	 * No SEO plugin active: Lift's own description, or else the one saved earlier in Yoast or Rank Math
	 * (their plugin was turned off or removed, but the owner's words are still there; found in testing, 9.11.2026).
	 *
	 * @param int $id Page ID.
	 * @return string
	 */
	private static function lift_description( $id ) {
		foreach ( array( self::META_DESC, '_yoast_wpseo_metadesc', 'rank_math_description' ) as $key ) {
			$value = trim( (string) get_post_meta( $id, $key, true ) );
			// Skip SEO-plugin templates such as %%sitename%% or %title%, which only they can fill in.
			if ( '' !== $value && ! preg_match( '/%%?[a-z_]+%%?/i', $value ) ) {
				return $value;
			}
		}
		return '';
	}

	/**
	 * A suggested description: the business sentence for the home page, else the excerpt or the first words.
	 *
	 * @param int $id Page ID.
	 * @return string
	 */
	public static function suggest_description( $id ) {
		$b = Business::get();
		if ( $id === self::front_id() && '' !== trim( $b['description'] ) ) {
			return trim( $b['description'] );
		}
		$post = get_post( $id );
		if ( ! $post ) {
			return '';
		}
		$content = strip_shortcodes( $post->post_content );
		$source  = '';
		if ( has_excerpt( $post ) ) {
			$source = $post->post_excerpt;
		} elseif ( preg_match_all( '#<p[^>]*>(.*?)</p>#is', $content, $paras ) ) {
			// Paragraphs only (not headings or buttons), until there is enough for a sentence or two.
			foreach ( $paras[1] as $para ) {
				$source .= ' ' . wp_strip_all_tags( $para );
				if ( mb_strlen( trim( $source ) ) >= 60 ) {
					break;
				}
			}
		}
		if ( '' === trim( $source ) ) {
			$source = preg_replace( '#</(p|h[1-6]|li|div|figure|figcaption|a|button|td|th)>#i', '$0 ', $content );
		}
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $source ) ) );
		if ( mb_strlen( $text ) <= 155 ) {
			return $text;
		}
		$cut   = mb_substr( $text, 0, 155 );
		$space = mb_strrpos( $cut, ' ' );
		return rtrim( false !== $space ? mb_substr( $cut, 0, $space ) : $cut, ' ,.;:-' ) . '…';
	}

	/**
	 * Saved check of a page.
	 *
	 * @param int $id Page ID.
	 * @return array|null
	 */
	public static function saved_scan( $id ) {
		$scan = $id ? get_post_meta( $id, self::META_SCAN, true ) : null;
		return is_array( $scan ) ? $scan : null;
	}

	/**
	 * Back to the readiness screen for this page, checking it again.
	 *
	 * @param int    $id     Page ID.
	 * @param string $notice Notice key.
	 */
	private static function back( $id, $notice ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => Readiness::PAGE_SLUG,
					'page_id' => (int) $id,
					'lift'    => $notice,
				),
				admin_url( 'admin.php' )
			) . '#' . self::ANCHOR
		);
		exit;
	}

	/**
	 * Choose the page (landing package), save a description, save image descriptions.
	 */
	public static function handle_action() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}
		check_admin_referer( self::ACTION );
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;

		if ( 'choose' === $do ) {
			if ( 'page' === get_post_type( $id ) && 'publish' === get_post_status( $id ) ) {
				update_option( self::OPTION_PAGE, $id, false );
				delete_option( Readiness::OPTION ); // The main score now belongs to the new page.
				self::back( $id, 'chosen' );
			}
			self::back( self::chosen(), '' );
		}

		if ( ! self::allowed( $id ) ) {
			wp_die( esc_html__( 'Lift does not fix this page in your package.', 'zarmumia-lift' ) );
		}

		if ( 'description' === $do ) {
			$key  = self::description_key();
			$desc = isset( $_POST['description'] ) ? sanitize_text_field( wp_unslash( $_POST['description'] ) ) : '';
			$desc = mb_substr( $desc, 0, self::MAX_DESC );
			if ( '' === $key ) {
				self::back( $id, 'none' );
			}
			if ( 'lift' === self::description_owner() ) {
				if ( '' === $desc ) {
					delete_post_meta( $id, $key );
				} else {
					update_post_meta( $id, $key, $desc );
				}
			} elseif ( '' !== $desc && '' === trim( (string) get_post_meta( $id, $key, true ) ) ) {
				update_post_meta( $id, $key, $desc ); // The SEO plugin's field, only when empty.
			}
			self::back( $id, 'description' );
		}

		if ( 'alts' === $do ) {
			$scan    = self::saved_scan( $id );
			$known   = $scan && ! empty( $scan['imgs'] ) ? (array) $scan['imgs'] : array();
			$alts    = self::alts( $id );
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each value is checked below.
			$srcs    = isset( $_POST['src'] ) ? (array) wp_unslash( $_POST['src'] ) : array();
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each value is sanitized below.
			$texts   = isset( $_POST['alt'] ) ? (array) wp_unslash( $_POST['alt'] ) : array();
			foreach ( $srcs as $i => $src ) {
				$src = (string) $src;
				if ( ! in_array( $src, $known, true ) && ! isset( $alts[ $src ] ) ) {
					continue; // Only images Lift found on this page.
				}
				$text = mb_substr( sanitize_text_field( (string) ( $texts[ $i ] ?? '' ) ), 0, self::MAX_ALT );
				if ( '' === $text ) {
					unset( $alts[ $src ] );
				} else {
					$alts[ $src ] = $text;
				}
			}
			$alts = array_filter( $alts );
			if ( $alts ) {
				update_post_meta( $id, self::META_ALTS, $alts );
			} else {
				delete_post_meta( $id, self::META_ALTS );
			}
			self::back( $id, 'alts' );
		}

		self::back( $id, '' );
	}

	/**
	 * Landing package: which page Lift checks and fixes.
	 */
	public static function render_choice() {
		$chosen = self::chosen();
		?>
		<form class="zarmumia-lift-choose" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( self::ACTION ); ?>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
			<input type="hidden" name="do" value="choose" />
			<label for="zarmumia-lift-page"><strong><?php esc_html_e( 'Your page:', 'zarmumia-lift' ); ?></strong></label>
			<?php self::page_select( 'page_id', $chosen, ! $chosen ); ?>
			<button type="submit" class="button"><?php esc_html_e( 'Save', 'zarmumia-lift' ); ?></button>
			<span class="zarmumia-lift-muted">
				<?php esc_html_e( 'Your package checks and fixes one page. You can switch pages any time; the fixes move to the new page.', 'zarmumia-lift' ); ?>
			</span>
			<?php Admin::site_tag(); ?>
		</form>
		<?php
	}

	/**
	 * A select of published pages.
	 *
	 * @param string $name        Field name.
	 * @param int    $selected    Selected page ID.
	 * @param bool   $placeholder Show "Choose a page".
	 */
	public static function page_select( $name, $selected, $placeholder = false ) {
		$front = self::front_id();
		echo '<select id="zarmumia-lift-page" name="' . esc_attr( $name ) . '">';
		if ( $placeholder ) {
			echo '<option value="0">' . esc_html__( 'Choose a page', 'zarmumia-lift' ) . '</option>';
		}
		foreach ( self::pages() as $p ) {
			$label = '' !== trim( $p->post_title ) ? $p->post_title : __( '(no title)', 'zarmumia-lift' );
			if ( (int) $p->ID === $front ) {
				/* translators: %s: page title. */
				$label = sprintf( __( '%s (home page)', 'zarmumia-lift' ), $label );
			}
			printf( '<option value="%d"%s>%s</option>', (int) $p->ID, selected( (int) $p->ID, (int) $selected, false ), esc_html( $label ) );
		}
		echo '</select>';
	}

	/**
	 * Notice after an action.
	 *
	 * @param string $key Notice key.
	 */
	public static function render_notice( $key ) {
		$notices = array(
			'chosen'      => __( 'Saved. Lift now checks and fixes this page.', 'zarmumia-lift' ),
			'description' => __( 'The description was saved. Lift is checking the page again.', 'zarmumia-lift' ),
			'alts'        => __( 'The image descriptions were saved. Lift is checking the page again.', 'zarmumia-lift' ),
		);
		if ( isset( $notices[ $key ] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $notices[ $key ] ) . '</p></div>';
		}
	}

	/**
	 * "Fixes for this page": the four fixes, with the result of the last check.
	 *
	 * @param int   $id   Page ID.
	 * @param array $scan The check of this page.
	 */
	public static function render_panel( $id, array $scan ) {
		$checks = $scan['checks'];
		$owner  = self::description_owner();
		$key    = self::description_key();
		$saved  = 'lift' === $owner ? self::lift_description( $id ) : ( '' !== $key ? trim( (string) get_post_meta( $id, $key, true ) ) : '' );
		$alts   = self::alts( $id );
		$imgs   = array_values( array_unique( array_merge( ! empty( $scan['imgs'] ) ? (array) $scan['imgs'] : array(), array_keys( $alts ) ) ) );
		$h1     = (int) ( $checks['h1'][1][0] ?? 0 );
		$faq    = Schema::faq_from_page( $id );
		$edit   = get_edit_post_link( $id, 'raw' );
		$names  = array(
			'yoast'    => 'Yoast SEO',
			'rankmath' => 'Rank Math',
			'aioseo'   => 'All in One SEO',
		);
		$status = function ( $check_id ) use ( $checks ) {
			return isset( $checks[ $check_id ] ) ? $checks[ $check_id ][0] : 'na';
		};
		?>
		<div class="zarmumia-lift-fixes" id="<?php echo esc_attr( self::ANCHOR ); ?>">
			<h2><?php esc_html_e( 'Fixes for this page', 'zarmumia-lift' ); ?></h2>
			<p class="zarmumia-lift-muted"><?php esc_html_e( 'Lift never changes your texts or design. It only adds what is missing, and you approve every word.', 'zarmumia-lift' ); ?></p>

			<?php /* 1. Description for search. */ ?>
			<div class="zarmumia-lift-fix is-<?php echo esc_attr( $status( 'description' ) ); ?>">
				<h3><span class="zarmumia-lift-dot"></span><?php esc_html_e( 'Description for Google', 'zarmumia-lift' ); ?></h3>
				<?php if ( 'aioseo' === $owner ) : ?>
					<p><?php esc_html_e( 'Your site uses All in One SEO, so the description is written there: open the page in the editor and fill in "Meta Description" in the All in One SEO box.', 'zarmumia-lift' ); ?>
						<?php if ( $edit ) : ?><a href="<?php echo esc_url( $edit ); ?>"><?php esc_html_e( 'Edit the page', 'zarmumia-lift' ); ?></a><?php endif; ?></p>
				<?php elseif ( 'lift' !== $owner && '' !== $saved ) : ?>
					<p>
						<?php
						/* translators: %s: SEO plugin name. */
						echo esc_html( sprintf( __( 'This page has a description in %s. To change it, edit it there (Lift never overwrites an existing description).', 'zarmumia-lift' ), $names[ $owner ] ) );
						?>
					</p>
					<blockquote><?php echo esc_html( $saved ); ?></blockquote>
				<?php else : ?>
					<p><?php esc_html_e( 'One or two sentences that appear under your page name in Google: what you do and for whom. Lift suggested one from your page; edit it in your own words.', 'zarmumia-lift' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( self::ACTION ); ?>
						<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
						<input type="hidden" name="do" value="description" />
						<input type="hidden" name="page_id" value="<?php echo (int) $id; ?>" />
						<textarea class="large-text" rows="3" maxlength="<?php echo (int) self::MAX_DESC; ?>" name="description" dir="auto"><?php echo esc_textarea( '' !== $saved ? $saved : self::suggest_description( $id ) ); ?></textarea>
						<p class="zarmumia-lift-muted">
							<?php
							echo esc_html(
								'lift' === $owner
									? __( 'Best length: about 120–155 characters. Lift adds it to the page code; your page looks the same. To remove it, empty the box and save.', 'zarmumia-lift' )
									/* translators: %s: SEO plugin name. */
									: sprintf( __( 'Best length: about 120–155 characters. Lift saves it in %s, where you can edit it later.', 'zarmumia-lift' ), $names[ $owner ] )
							);
							?>
						</p>
						<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Save the description', 'zarmumia-lift' ); ?></button></p>
					</form>
				<?php endif; ?>
			</div>

			<?php /* 2. Image descriptions. */ ?>
			<div class="zarmumia-lift-fix is-<?php echo esc_attr( $status( 'alt' ) ); ?>">
				<h3><span class="zarmumia-lift-dot"></span><?php esc_html_e( 'Image descriptions', 'zarmumia-lift' ); ?></h3>
				<?php if ( ! $imgs ) : ?>
					<p><?php esc_html_e( 'All images on this page have a description. Nothing to do.', 'zarmumia-lift' ); ?></p>
				<?php else : ?>
					<p><?php esc_html_e( 'Write in one short sentence what each image shows. Lift adds it only to images without a description, while the page is shown; the page itself does not change.', 'zarmumia-lift' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<?php wp_nonce_field( self::ACTION ); ?>
						<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
						<input type="hidden" name="do" value="alts" />
						<input type="hidden" name="page_id" value="<?php echo (int) $id; ?>" />
						<ul class="zarmumia-lift-images">
							<?php foreach ( $imgs as $i => $src ) : ?>
								<li>
									<img src="<?php echo esc_url( $src ); ?>" alt="" loading="lazy" />
									<input type="hidden" name="src[<?php echo (int) $i; ?>]" value="<?php echo esc_attr( $src ); ?>" />
									<input type="text" class="regular-text" dir="auto" maxlength="<?php echo (int) self::MAX_ALT; ?>" name="alt[<?php echo (int) $i; ?>]" value="<?php echo esc_attr( $alts[ $src ] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'For example: Two women talking at a desk with a laptop', 'zarmumia-lift' ); ?>" />
								</li>
							<?php endforeach; ?>
						</ul>
						<p><button type="submit" class="button button-primary"><?php esc_html_e( 'Save the descriptions', 'zarmumia-lift' ); ?></button></p>
					</form>
				<?php endif; ?>
			</div>

			<?php /* 3. Main heading: explain only. */ ?>
			<div class="zarmumia-lift-fix is-<?php echo esc_attr( $status( 'h1' ) ); ?>">
				<h3><span class="zarmumia-lift-dot"></span><?php esc_html_e( 'Main heading', 'zarmumia-lift' ); ?></h3>
				<?php if ( 1 === $h1 ) : ?>
					<p><?php esc_html_e( 'The page has one main heading, as it should. Nothing to do.', 'zarmumia-lift' ); ?></p>
				<?php else : ?>
					<p>
						<?php
						echo esc_html(
							0 === $h1
								? __( 'The page has no main heading (H1). It is the heading that says what the page is about.', 'zarmumia-lift' )
								/* translators: %s: number of main headings. */
								: sprintf( __( 'The page has %s main headings (H1). There should be one, saying what the page is about.', 'zarmumia-lift' ), number_format_i18n( $h1 ) )
						);
						?>
					</p>
					<p><?php esc_html_e( 'Lift does not change your texts, so this one is yours: in the page editor, click the heading and choose "H1" for the main one and "H2" for the others. The text and the look can stay the same.', 'zarmumia-lift' ); ?>
						<?php if ( $edit ) : ?><a href="<?php echo esc_url( $edit ); ?>"><?php esc_html_e( 'Edit the page', 'zarmumia-lift' ); ?></a><?php endif; ?></p>
				<?php endif; ?>
			</div>

			<?php /* 4. Questions and answers. */ ?>
			<div class="zarmumia-lift-fix is-<?php echo esc_attr( $faq ? 'pass' : 'warn' ); ?>">
				<h3><span class="zarmumia-lift-dot"></span><?php esc_html_e( 'Questions and answers', 'zarmumia-lift' ); ?></h3>
				<?php if ( $faq ) : ?>
					<p>
						<?php
						/* translators: %s: number of questions. */
						echo esc_html( sprintf( _n( 'Lift found %s question on this page and marks it for Google and AI engines:', 'Lift found %s questions on this page and marks them for Google and AI engines:', count( $faq ), 'zarmumia-lift' ), number_format_i18n( count( $faq ) ) ) );
						?>
					</p>
					<ul class="zarmumia-lift-faq">
						<?php foreach ( $faq as $qa ) : ?>
							<li><?php echo esc_html( $qa[0] ); ?></li>
						<?php endforeach; ?>
					</ul>
					<?php if ( ! Schema::is_enabled() ) : ?>
						<p><?php esc_html_e( 'To send them, turn on business details in Lift.', 'zarmumia-lift' ); ?> <a href="<?php echo esc_url( admin_url( 'admin.php?page=' . Admin::SCHEMA_SLUG ) ); ?>"><?php esc_html_e( 'Go there', 'zarmumia-lift' ); ?></a></p>
					<?php endif; ?>
				<?php else : ?>
					<p><?php esc_html_e( 'No questions and answers were found on this page. Questions your clients ask, with short answers, are easy for AI engines to quote.', 'zarmumia-lift' ); ?></p>
					<p><?php esc_html_e( 'To add some: in the page editor, add a heading that ends with "?" and a short paragraph with the answer under it. At least two questions. Lift will find them by itself.', 'zarmumia-lift' ); ?>
						<?php if ( $edit ) : ?><a href="<?php echo esc_url( $edit ); ?>"><?php esc_html_e( 'Edit the page', 'zarmumia-lift' ); ?></a><?php endif; ?></p>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
