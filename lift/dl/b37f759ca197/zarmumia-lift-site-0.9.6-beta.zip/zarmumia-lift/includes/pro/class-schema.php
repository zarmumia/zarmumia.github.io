<?php
/**
 * Schema (JSON-LD): business details for search and AI engines.
 *
 * Rule: never a second business block. When Yoast, Rank Math or All in One SEO output schema, Lift adds the
 * missing details to THEIR business entry (or adds one entry to their graph if they have none). Without an SEO
 * plugin, Lift outputs its own small graph.
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Schema feature.
 */
class Schema {

	const OPTION    = 'zarmumia_lift_schema';
	const ACTION    = 'zarmumia_lift_schema';
	const PAGE_SLUG = 'zarmumia-lift-schema';

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		if ( is_admin() ) {
			add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_action' ) );
			return;
		}
		if ( ! self::is_enabled() ) {
			return;
		}
		add_filter( 'wpseo_schema_graph', array( __CLASS__, 'filter_graph_list' ), 20 );
		add_filter( 'aioseo_schema_output', array( __CLASS__, 'filter_graph_list' ), 20 );
		add_filter( 'rank_math/json_ld', array( __CLASS__, 'filter_rank_math' ), 99 );
		add_action( 'wp_head', array( __CLASS__, 'output_own' ), 20 );
	}

	/**
	 * Is schema output switched on (and the wizard done)?
	 *
	 * @return bool
	 */
	public static function is_enabled() {
		$state = get_option( self::OPTION, array() );
		return is_array( $state ) && ! empty( $state['enabled'] ) && Business::is_complete();
	}

	/**
	 * Which SEO plugin outputs schema on this site, if any.
	 *
	 * @return string Empty when none.
	 */
	public static function seo_plugin() {
		if ( defined( 'WPSEO_VERSION' ) ) {
			return 'Yoast SEO';
		}
		if ( Robots::rank_math_ready() ) {
			return 'Rank Math';
		}
		if ( defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' ) ) {
			return 'All in One SEO';
		}
		return '';
	}

	/**
	 * Lift's business entry, built from the wizard answers. Only filled fields are included.
	 *
	 * @return array
	 */
	public static function business_node() {
		$b    = Business::get();
		$node = array(
			'@type' => $b['city'] ? 'LocalBusiness' : 'Organization',
			'@id'   => home_url( '/#organization' ),
			'name'  => $b['name'],
			'url'   => home_url( '/' ),
		);
		if ( '' !== trim( $b['description'] ) ) {
			$node['description'] = $b['description'];
		}
		if ( $b['founder_name'] ) {
			$node['founder'] = array_filter(
				array(
					'@type'    => 'Person',
					'name'     => $b['founder_name'],
					'jobTitle' => $b['founder_role'],
				)
			);
		}
		if ( $b['city'] ) {
			$node['address'] = array(
				'@type'           => 'PostalAddress',
				'addressLocality' => $b['city'],
			);
			if ( 'he' === substr( get_locale(), 0, 2 ) ) {
				$node['address']['addressCountry'] = 'IL';
			}
		}
		if ( $b['area'] ) {
			$node['areaServed'] = $b['area'];
		}
		if ( $b['languages'] ) {
			$node['knowsLanguage'] = array_values( $b['languages'] );
		}
		if ( $b['phone'] ) {
			$node['telephone'] = $b['phone'];
		}
		if ( $b['email'] ) {
			$node['email'] = $b['email'];
		}
		$same_as = array_values( array_filter( $b['links'] ) );
		if ( $same_as ) {
			$node['sameAs'] = $same_as;
		}
		$logo = self::logo_url();
		if ( $logo ) {
			$node['logo']  = $logo;
			$node['image'] = $logo; // Google lists a missing "image" as a note (Rich Results Test, 9.11.2026).
		}
		return $node;
	}

	/**
	 * The business logo: the one chosen in Lift, else the site's own (theme logo, else site icon).
	 *
	 * @return string Empty when there is none.
	 */
	public static function logo_url() {
		$chosen = (int) Business::get()['logo'];
		$url    = $chosen ? wp_get_attachment_image_url( $chosen, 'full' ) : '';
		return $url ? $url : Wizard::site_logo_url();
	}

	/**
	 * Is this graph entry a business / organisation?
	 *
	 * @param array $node Graph entry.
	 * @return bool
	 */
	private static function is_business( $node ) {
		if ( ! is_array( $node ) || empty( $node['@type'] ) ) {
			return false;
		}
		$known = array( 'Organization', 'LocalBusiness', 'ProfessionalService', 'Corporation', 'OnlineBusiness', 'NGO', 'Store', 'EducationalOrganization' );
		foreach ( (array) $node['@type'] as $type ) {
			if ( in_array( $type, $known, true ) || 'Business' === substr( (string) $type, -8 ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Add only what is missing to an existing business entry. Never overwrites the SEO plugin's values.
	 *
	 * @param array $existing The SEO plugin's entry.
	 * @return array
	 */
	private static function complete( array $existing ) {
		$ours = self::business_node();
		unset( $ours['@type'], $ours['@id'] );
		foreach ( $ours as $key => $value ) {
			if ( 'sameAs' === $key ) {
				$existing['sameAs'] = array_values( array_unique( array_merge( (array) ( $existing['sameAs'] ?? array() ), $value ) ) );
			} elseif ( ! isset( $existing[ $key ] ) || '' === $existing[ $key ] || array() === $existing[ $key ] ) {
				$existing[ $key ] = $value;
			}
		}
		return $existing;
	}

	/**
	 * Questions and answers found on the current page: a heading that ends with "?" followed by paragraphs.
	 *
	 * @return array List of [question, answer]. Empty unless at least 2 were found.
	 */
	public static function faq_from_page( $post = null ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return array();
		}
		// The question text may not contain another heading, so one match never swallows the next question.
		// Block comments (<!-- wp:... -->) between the heading and the answer are skipped, one comment at a time.
		$comment = '<!--(?:(?!-->).)*-->';
		$pattern = '#<h([2-4])[^>]*>((?:(?!</?h[1-6]).)*?)</h\1>\s*(?:' . $comment . '\s*)*((?:<p[^>]*>(?:(?!</p>).)*</p>\s*(?:' . $comment . '\s*)*)+)#s';
		if ( ! preg_match_all( $pattern, $post->post_content, $matches, PREG_SET_ORDER ) ) {
			return array();
		}
		$faq = array();
		foreach ( $matches as $m ) {
			$question = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $m[2] ) ) );
			if ( '?' !== mb_substr( $question, -1 ) ) {
				continue;
			}
			$answer = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( str_replace( '</p>', '</p> ', $m[3] ) ) ) );
			if ( '' !== $answer ) {
				$faq[] = array( $question, $answer );
			}
		}
		// Expand/collapse questions: <details><summary>Question?</summary> answer </details> (common in Elementor HTML widgets),
		// and Elementor's accordion / toggle widgets.
		$patterns = array(
			'#<details[^>]*>\s*<summary[^>]*>(.*?)</summary>(.*?)</details>#s',
			'#class="elementor-(?:tab|toggle|accordion)-title[^"]*"[^>]*>(.*?)</(?:a|div|span)>.*?class="elementor-tab-content[^"]*"[^>]*>(.*?)</div>#s',
		);
		foreach ( $patterns as $p ) {
			if ( preg_match_all( $p, $post->post_content, $more, PREG_SET_ORDER ) ) {
				foreach ( $more as $m ) {
					$question = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $m[1] ) ) );
					$answer   = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( str_replace( '</p>', '</p> ', $m[2] ) ) ) );
					if ( '?' === mb_substr( $question, -1 ) && '' !== $answer ) {
						$faq[] = array( $question, $answer );
					}
				}
			}
		}
		return count( $faq ) >= 2 ? $faq : array();
	}

	/**
	 * FAQPage entry for the current page, or null.
	 *
	 * @return array|null
	 */
	private static function faq_node() {
		if ( ! is_singular() ) {
			return null;
		}
		if ( ! ZARMUMIA_LIFT_SITE && ! Page_Fixes::allowed( get_queried_object_id() ) ) {
			return null; // Landing page package: questions and answers only on the chosen page (decided 9.11.2026).
		}
		$faq = self::faq_from_page();
		if ( ! $faq ) {
			return null;
		}
		$url = get_permalink();
		return array(
			'@type'      => 'FAQPage',
			'@id'        => $url . '#faq',
			'url'        => $url,
			'mainEntity' => array_map(
				function ( $qa ) {
					return array(
						'@type'          => 'Question',
						'name'           => $qa[0],
						'acceptedAnswer' => array(
							'@type' => 'Answer',
							'text'  => $qa[1],
						),
					);
				},
				$faq
			),
		);
	}

	/**
	 * Does the graph already have an FAQPage (for example from Yoast's FAQ block)?
	 *
	 * @param array $graph Graph entries.
	 * @return bool
	 */
	private static function has_faq( array $graph ) {
		foreach ( $graph as $node ) {
			if ( is_array( $node ) && ! empty( $node['@type'] ) && in_array( 'FAQPage', (array) $node['@type'], true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Yoast and All in One SEO: complete their graph (a plain list of entries).
	 *
	 * @param array $graph Graph entries.
	 * @return array
	 */
	public static function filter_graph_list( $graph ) {
		if ( ! is_array( $graph ) ) {
			return $graph;
		}
		$found = false;
		foreach ( $graph as $i => $node ) {
			if ( self::is_business( $node ) ) {
				$graph[ $i ] = self::complete( $node );
				$found       = true;
				break; // Only the main business entry.
			}
		}
		if ( ! $found ) {
			$graph[] = self::business_node();
			foreach ( $graph as $i => $node ) {
				if ( is_array( $node ) && in_array( 'WebSite', (array) ( $node['@type'] ?? array() ), true ) && empty( $node['publisher'] ) ) {
					$graph[ $i ]['publisher'] = array( '@id' => home_url( '/#organization' ) );
				}
			}
		}
		if ( ! self::has_faq( $graph ) ) {
			$faq = self::faq_node();
			if ( $faq ) {
				$graph[] = $faq;
			}
		}
		return $graph;
	}

	/**
	 * Rank Math: its schema is a list keyed by name.
	 *
	 * @param array $data Rank Math schema data.
	 * @return array
	 */
	public static function filter_rank_math( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}
		$found = false;
		foreach ( $data as $key => $node ) {
			if ( self::is_business( $node ) ) {
				$data[ $key ] = self::complete( $node );
				$found        = true;
				break;
			}
		}
		if ( ! $found ) {
			$data['zarmumiaLiftBusiness'] = self::business_node();
		}
		if ( ! self::has_faq( $data ) ) {
			$faq = self::faq_node();
			if ( $faq ) {
				$data['zarmumiaLiftFaq'] = $faq;
			}
		}
		return $data;
	}

	/**
	 * No SEO plugin: Lift outputs its own small graph.
	 */
	public static function output_own() {
		if ( '' !== self::seo_plugin() ) {
			return;
		}
		$graph = array(
			self::business_node(),
			array(
				'@type'     => 'WebSite',
				'@id'       => home_url( '/#website' ),
				'url'       => home_url( '/' ),
				'name'      => Business::get()['name'],
				'publisher' => array( '@id' => home_url( '/#organization' ) ),
			),
		);
		$faq = self::faq_node();
		if ( $faq ) {
			$graph[] = $faq;
		}
		$json = wp_json_encode(
			array(
				'@context' => 'https://schema.org',
				'@graph'   => $graph,
			),
			JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
		);
		echo "\n<script type=\"application/ld+json\" class=\"zarmumia-lift-schema\">" . str_replace( '</', '<\/', $json ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON, with "</" escaped.
	}

	/**
	 * Turn on / off.
	 */
	public static function handle_action() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}
		check_admin_referer( self::ACTION );
		$on = isset( $_POST['do'] ) && 'enable' === sanitize_key( wp_unslash( $_POST['do'] ) );
		update_option( self::OPTION, array( 'enabled' => $on ), false );
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'notice' => $on ? 'on' : 'off' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * The schema screen.
	 */
	public static function render() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}
		$enabled = self::is_enabled();
		$seo     = self::seo_plugin();
		$front   = (int) get_option( 'page_on_front' );
		$faq     = $front ? self::faq_from_page( $front ) : array();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flag after redirect.
		$notice = isset( $_GET['notice'] ) ? sanitize_key( wp_unslash( $_GET['notice'] ) ) : '';
		?>
		<div class="wrap zarmumia-lift">
			<h1><?php esc_html_e( 'Business details for search and AI engines', 'zarmumia-lift' ); ?></h1>

			<?php if ( 'on' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Turned on. Your business details are now part of your site\'s code. Nothing visible on the page changed.', 'zarmumia-lift' ); ?></p></div>
			<?php elseif ( 'off' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Turned off. Lift no longer adds business details.', 'zarmumia-lift' ); ?></p></div>
			<?php endif; ?>

			<div class="zarmumia-lift-card">
				<p><?php esc_html_e( 'Search engines and AI engines read a hidden summary in your page\'s code ("schema"): who the business is, where it works, in which languages, and how to reach it. Visitors do not see it, and your page does not change.', 'zarmumia-lift' ); ?></p>

				<?php if ( ! Business::is_complete() ) : ?>
					<p><?php esc_html_e( 'First answer the short questions about your business. Lift builds the details from your answers.', 'zarmumia-lift' ); ?></p>
					<p><a class="button button-primary" href="<?php echo esc_url( Wizard::url( 'business' ) ); ?>"><?php esc_html_e( 'Start', 'zarmumia-lift' ); ?></a></p>
				<?php else : ?>
					<div class="zarmumia-lift-status <?php echo $enabled ? 'zarmumia-lift-status--ok' : ''; ?>">
						<strong><?php echo $enabled ? esc_html__( 'On.', 'zarmumia-lift' ) : esc_html__( 'Off.', 'zarmumia-lift' ); ?></strong>
						<?php
						if ( $seo ) {
							/* translators: %s: SEO plugin name, e.g. Yoast SEO. */
							echo esc_html( sprintf( __( '%s is installed, so Lift adds only what is missing to its business details, without creating a second set.', 'zarmumia-lift' ), $seo ) );
						} else {
							esc_html_e( 'No SEO plugin was found, so Lift adds the business details itself.', 'zarmumia-lift' );
						}
						?>
					</div>

					<h3><?php esc_html_e( 'What Lift adds', 'zarmumia-lift' ); ?></h3>
					<textarea class="large-text code" rows="14" readonly dir="ltr"><?php echo esc_textarea( wp_json_encode( self::business_node(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
					<p class="zarmumia-lift-muted">
						<?php
						if ( $faq ) {
							/* translators: %s: number of questions. */
							echo esc_html( sprintf( __( 'Questions and answers found on your home page: %s. Lift adds them too.', 'zarmumia-lift' ), number_format_i18n( count( $faq ) ) ) );
						} else {
							esc_html_e( 'No questions and answers were found on your home page.', 'zarmumia-lift' );
						}
						?>
					</p>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="zarmumia-lift-actions">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
						<?php wp_nonce_field( self::ACTION ); ?>
						<?php if ( $enabled ) : ?>
							<button type="submit" class="button" name="do" value="disable"><?php esc_html_e( 'Turn off', 'zarmumia-lift' ); ?></button>
						<?php else : ?>
							<button type="submit" class="button button-primary" name="do" value="enable"><?php esc_html_e( 'Turn on', 'zarmumia-lift' ); ?></button>
						<?php endif; ?>
						<a class="button" href="<?php echo esc_url( Wizard::url( 'business' ) ); ?>"><?php esc_html_e( 'Edit details', 'zarmumia-lift' ); ?></a>
					</form>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
