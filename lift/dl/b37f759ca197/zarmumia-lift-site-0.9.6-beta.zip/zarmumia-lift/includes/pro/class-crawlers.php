<?php
/**
 * AI crawlers in robots.txt, and the sitemap.
 *
 * Rules: nothing changes without an explicit click; Lift never edits or removes another plugin's lines.
 * When the owner opens a group of crawlers, Lift adds its own clearly marked block at the end of the
 * WordPress robots.txt, and can take it away again. A real robots.txt file on the server cannot be changed
 * by WordPress, so then Lift only explains.
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Crawlers and sitemap feature (full version only).
 */
class Crawlers extends Robots {

	const OPTION    = 'zarmumia_lift_robots';
	const ACTION    = 'zarmumia_lift_robots';
	const PAGE_SLUG = 'zarmumia-lift-crawlers';

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		add_filter( 'robots_txt', array( __CLASS__, 'filter_robots' ), 99999, 2 );
		if ( is_admin() ) {
			add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_action' ) );
		}
	}

	/**
	 * Saved choices.
	 *
	 * @return array
	 */
	public static function state() {
		$state = get_option( self::OPTION, array() );
		return array_merge(
			array(
				'open_search'   => false,
				'open_training' => false,
				'add_sitemap'   => false,
			),
			is_array( $state ) ? $state : array()
		);
	}

	/**
	 * Lift's own block, added at the end of the WordPress robots.txt. Empty when the owner chose nothing.
	 *
	 * @return string
	 */
	public static function lift_block() {
		$state  = self::state();
		$groups = self::groups();
		$bots   = array();
		if ( $state['open_search'] ) {
			$bots = array_merge( $bots, $groups['search'] );
		}
		if ( $state['open_training'] ) {
			$bots = array_merge( $bots, $groups['training'] );
		}
		$sitemap = $state['add_sitemap'] ? self::sitemap_url() : '';
		if ( ! $bots && ! $sitemap ) {
			return '';
		}
		$lines = array( '# START LIFT BY ZARMUMIA BLOCK' );
		if ( $bots ) {
			foreach ( $bots as $bot ) {
				$lines[] = 'User-agent: ' . $bot;
			}
			$lines[] = 'Allow: /';
		}
		if ( $sitemap ) {
			if ( $bots ) {
				$lines[] = '';
			}
			$lines[] = 'Sitemap: ' . $sitemap;
		}
		$lines[] = '# END LIFT BY ZARMUMIA BLOCK';
		return implode( "\n", $lines );
	}

	/**
	 * robots_txt filter: append Lift's block (runs after other plugins, never edits their lines).
	 *
	 * @param string $output Robots text so far.
	 * @param string $public Site visibility setting.
	 * @return string
	 */
	public static function filter_robots( $output, $public ) {
		if ( '0' === (string) $public ) {
			return $output; // The owner asked search engines not to index the site; Lift does not override that.
		}
		$block = self::lift_block();
		return '' === $block ? $output : rtrim( $output ) . "\n\n" . $block . "\n";
	}


	/**
	 * Save a choice.
	 */
	public static function handle_action() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}
		check_admin_referer( self::ACTION );
		delete_transient( self::ROBOTS_CACHE );
		$do     = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$state  = self::state();
		$notice = 'saved';

		switch ( $do ) {
			case 'open_search':
			case 'open_training':
				$state[ $do ] = true;
				break;
			case 'add_sitemap':
				$state['add_sitemap'] = true;
				break;
			case 'undo':
				$state = array(
					'open_search'   => false,
					'open_training' => false,
					'add_sitemap'   => false,
				);
				$notice = 'undone';
				break;
			case 'sitemap_to_llms':
				$url  = self::sitemap_url();
				$llms = Llms::state();
				if ( $url && ! empty( $llms['published'] ) && false === strpos( $llms['content'], $url ) ) {
					// One "## Optional" heading only (it may already be there).
					$heading         = preg_match( '/^## Optional\s*$/m', $llms['content'] ) ? "\n" : "\n\n## Optional\n\n";
					$llms['content'] = rtrim( $llms['content'] ) . $heading . '- [Sitemap](' . $url . ")\n";
					update_option( Llms::OPTION, $llms, false );
				}
				$notice = 'llms';
				break;
		}
		update_option( self::OPTION, $state, false );
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'notice' => $notice ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * A one-click form button.
	 *
	 * @param string $do      Action.
	 * @param string $label   Button text.
	 * @param bool   $primary Primary style.
	 */
	private static function button( $do, $label, $primary = true ) {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="zarmumia-lift-inline-form">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
			<?php wp_nonce_field( self::ACTION ); ?>
			<button type="submit" class="button <?php echo $primary ? 'button-primary' : ''; ?>" name="do" value="<?php echo esc_attr( $do ); ?>"><?php echo esc_html( $label ); ?></button>
		</form>
		<?php
	}

	/**
	 * The screen.
	 */
	public static function render() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}
		$state    = self::state();
		$status   = self::status();
		$physical = self::physical_file();
		$public   = '0' !== (string) get_option( 'blog_public' );
		$sitemap  = self::sitemap_info();
		$mentions = self::sitemap_mentions( $sitemap['url'] );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flag after redirect.
		$notice = isset( $_GET['notice'] ) ? sanitize_key( wp_unslash( $_GET['notice'] ) ) : '';

		$titles = array(
			'search'   => __( 'AI search crawlers', 'zarmumia-lift' ),
			'training' => __( 'AI training crawlers', 'zarmumia-lift' ),
			'classic'  => __( 'Google and Bing', 'zarmumia-lift' ),
		);
		$explain = array(
			'search'   => __( 'They read your site when someone asks ChatGPT, Claude or Perplexity a question, so your business can be part of the answer.', 'zarmumia-lift' ),
			'training' => __( 'They collect text to train AI models. Blocking them does not stop AI search crawlers. Many owners keep them closed; it is your choice.', 'zarmumia-lift' ),
			'classic'  => __( 'Regular search engines. Google\'s AI answers also rely on Googlebot.', 'zarmumia-lift' ),
		);
		?>
		<div class="wrap zarmumia-lift">
			<h1><?php esc_html_e( 'AI crawlers and sitemap', 'zarmumia-lift' ); ?></h1>

			<?php if ( 'undone' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Lift\'s changes to robots.txt were removed. It is back to how it was.', 'zarmumia-lift' ); ?></p></div>
			<?php elseif ( 'llms' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'The sitemap link was added to your llms.txt.', 'zarmumia-lift' ); ?></p></div>
			<?php elseif ( 'saved' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved. robots.txt was updated.', 'zarmumia-lift' ); ?></p></div>
			<?php endif; ?>

			<?php if ( ! $public ) : ?>
				<div class="notice notice-error"><p>
					<strong><?php esc_html_e( 'Your site asks search engines not to index it.', 'zarmumia-lift' ); ?></strong>
					<?php esc_html_e( 'This is the WordPress setting "Discourage search engines from indexing this site". Lift does not change it for you.', 'zarmumia-lift' ); ?>
					<a href="<?php echo esc_url( admin_url( 'options-reading.php' ) ); ?>"><?php esc_html_e( 'Open the setting', 'zarmumia-lift' ); ?></a>
				</p></div>
			<?php endif; ?>

			<div class="zarmumia-lift-card">
				<h2><?php esc_html_e( 'Who can read your site', 'zarmumia-lift' ); ?></h2>
				<p><?php esc_html_e( 'robots.txt is a small file that tells crawlers what they may read. Lift shows the current state and changes nothing unless you click.', 'zarmumia-lift' ); ?></p>
				<?php if ( $physical ) : ?>
					<div class="zarmumia-lift-status zarmumia-lift-status--info">
						<?php esc_html_e( 'Your site has a robots.txt file on the server. WordPress plugins cannot change it, so Lift can only show its state. To change it, ask whoever manages your hosting.', 'zarmumia-lift' ); ?>
					</div>
				<?php endif; ?>

				<?php foreach ( $status as $group => $bots ) : ?>
					<?php $blocked = array_keys( array_filter( $bots, function ( $ok ) { return ! $ok; } ) ); ?>
					<h3><?php echo esc_html( $titles[ $group ] ); ?></h3>
					<p class="zarmumia-lift-muted"><?php echo esc_html( $explain[ $group ] ); ?></p>
					<ul class="zarmumia-lift-bots">
						<?php foreach ( $bots as $bot => $ok ) : ?>
							<li class="<?php echo $ok ? 'is-open' : 'is-blocked'; ?>">
								<span class="zarmumia-lift-dot"></span><bdi><?php echo esc_html( $bot ); ?></bdi>
								<span class="zarmumia-lift-muted"><?php echo $ok ? esc_html__( 'can read', 'zarmumia-lift' ) : esc_html__( 'blocked', 'zarmumia-lift' ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
					<?php if ( $blocked && 'classic' !== $group && ! $physical && $public ) : ?>
						<?php self::button( 'open_' . $group, 'search' === $group ? __( 'Open AI search crawlers', 'zarmumia-lift' ) : __( 'Open AI training crawlers', 'zarmumia-lift' ), 'search' === $group ); ?>
					<?php elseif ( $blocked && 'classic' === $group ) : ?>
						<p class="zarmumia-lift-status zarmumia-lift-status--info"><?php esc_html_e( 'Google or Bing are blocked. This hurts your visibility everywhere. Check the robots.txt setting in your SEO plugin, or ask whoever built your site.', 'zarmumia-lift' ); ?></p>
					<?php endif; ?>
				<?php endforeach; ?>

				<?php if ( $state['open_search'] || $state['open_training'] || $state['add_sitemap'] ) : ?>
					<p><?php esc_html_e( 'Lift added its own short block at the end of robots.txt. You can remove it at any time.', 'zarmumia-lift' ); ?></p>
					<?php self::button( 'undo', __( 'Remove Lift\'s changes', 'zarmumia-lift' ), false ); ?>
				<?php endif; ?>
			</div>

			<div class="zarmumia-lift-card">
				<h2><?php esc_html_e( 'Sitemap', 'zarmumia-lift' ); ?></h2>
				<p><?php esc_html_e( 'A sitemap lists your pages so crawlers find all of them. Lift never creates a second one.', 'zarmumia-lift' ); ?></p>
				<?php if ( $sitemap['url'] ) : ?>
					<ul class="zarmumia-lift-bots">
						<li class="is-open"><span class="zarmumia-lift-dot"></span>
							<?php
							/* translators: %s: who makes the sitemap, e.g. Yoast SEO. */
							echo esc_html( sprintf( __( 'Found, made by %s:', 'zarmumia-lift' ), $sitemap['source'] ) );
							?>
							<a href="<?php echo esc_url( $sitemap['url'] ); ?>" target="_blank" rel="noopener"><bdi><?php echo esc_html( $sitemap['url'] ); ?></bdi></a>
						</li>
						<li class="<?php echo $mentions['robots'] ? 'is-open' : 'is-blocked'; ?>"><span class="zarmumia-lift-dot"></span>
							<?php echo $mentions['robots'] ? esc_html__( 'Listed in robots.txt', 'zarmumia-lift' ) : esc_html__( 'Not listed in robots.txt', 'zarmumia-lift' ); ?>
						</li>
						<?php if ( null !== $mentions['llms'] ) : ?>
							<li class="<?php echo $mentions['llms'] ? 'is-open' : 'is-blocked'; ?>"><span class="zarmumia-lift-dot"></span>
								<?php echo $mentions['llms'] ? esc_html__( 'Listed in your llms.txt', 'zarmumia-lift' ) : esc_html__( 'Not listed in your llms.txt', 'zarmumia-lift' ); ?>
							</li>
						<?php endif; ?>
					</ul>
					<?php
					if ( ! $mentions['robots'] && ! $physical && $public ) {
						self::button( 'add_sitemap', __( 'Add the sitemap to robots.txt', 'zarmumia-lift' ) );
					}
					if ( false === $mentions['llms'] ) {
						self::button( 'sitemap_to_llms', __( 'Add the sitemap to llms.txt', 'zarmumia-lift' ), $mentions['robots'] );
					}
					?>
				<?php else : ?>
					<p class="zarmumia-lift-status zarmumia-lift-status--info"><?php esc_html_e( 'No sitemap was found. WordPress makes one by default; it may be turned off by a plugin or by your theme.', 'zarmumia-lift' ); ?></p>
				<?php endif; ?>
			</div>

			<div class="zarmumia-lift-card">
				<h2><?php esc_html_e( 'Your robots.txt right now', 'zarmumia-lift' ); ?></h2>
				<textarea class="large-text code" rows="10" readonly dir="ltr"><?php echo esc_textarea( self::effective_robots() ); ?></textarea>
			</div>
		</div>
		<?php
	}
}
