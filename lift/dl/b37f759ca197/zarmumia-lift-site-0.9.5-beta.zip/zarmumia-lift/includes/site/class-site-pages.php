<?php
/**
 * Whole site package: checks and fixes for every published page, and the all-pages table.
 *
 * This folder is left out of the Landing page download (tools/build-zips.ps1). Pages only, not blog posts
 * (decided 9.11.2026).
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * All-pages feature.
 */
class Site_Pages {

	/**
	 * Secret download folder of the Whole site package on zarmumia.co.il (update by click). Only in this package.
	 */
	const DOWNLOADS = 'b37f759ca197';

	/**
	 * What the "Check all pages" button needs: every page's address.
	 *
	 * @return array
	 */
	public static function script_data() {
		$pages = array();
		foreach ( Page_Fixes::pages() as $p ) {
			$pages[] = array(
				'id'  => (int) $p->ID,
				'url' => (string) get_permalink( $p ),
			);
		}
		return array(
			'pages'    => $pages,
			/* translators: 1: page number being checked, 2: number of pages. */
			'progress' => __( 'Checking page %1$s of %2$s…', 'zarmumia-lift' ),
		);
	}

	/**
	 * Which page to show on the readiness screen.
	 *
	 * @param int $current Page shown now.
	 */
	public static function render_switch( $current ) {
		?>
		<form class="zarmumia-lift-choose" method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
			<input type="hidden" name="page" value="<?php echo esc_attr( Readiness::PAGE_SLUG ); ?>" />
			<label for="zarmumia-lift-page"><strong><?php esc_html_e( 'Page to check:', 'zarmumia-lift' ); ?></strong></label>
			<?php Page_Fixes::page_select( 'page_id', $current, ! $current ); ?>
			<button type="submit" class="button"><?php esc_html_e( 'Show', 'zarmumia-lift' ); ?></button>
		</form>
		<?php
	}

	/**
	 * One cell: done, to fix, or not checked.
	 *
	 * @param array|null $scan  Saved check.
	 * @param string     $check Check id.
	 */
	private static function cell( $scan, $check ) {
		if ( ! $scan || ! isset( $scan['checks'][ $check ] ) ) {
			echo '<td class="is-none"><span class="zarmumia-lift-muted">–</span></td>';
			return;
		}
		$status = $scan['checks'][ $check ][0];
		$label  = 'pass' === $status ? __( 'Done', 'zarmumia-lift' ) : ( 'faq' === $check ? __( 'None', 'zarmumia-lift' ) : __( 'To fix', 'zarmumia-lift' ) );
		printf( '<td class="is-%s"><span class="zarmumia-lift-dot"></span> %s</td>', esc_attr( $status ), esc_html( $label ) );
	}

	/**
	 * The all-pages table.
	 *
	 * @param int $current Page shown above.
	 */
	public static function render_table( $current ) {
		$pages   = Page_Fixes::pages();
		$checked = 0;
		$todo    = 0;
		$rows    = array();
		foreach ( $pages as $p ) {
			$scan = Readiness::saved( (int) $p->ID );
			if ( ! $scan && (int) $p->ID === Page_Fixes::front_id() ) {
				$scan = Page_Fixes::saved_scan( (int) $p->ID );
			}
			if ( $scan ) {
				$checked++;
				foreach ( array( 'description', 'alt', 'h1' ) as $check ) {
					if ( isset( $scan['checks'][ $check ] ) && 'pass' !== $scan['checks'][ $check ][0] ) {
						$todo++;
						break;
					}
				}
			}
			$rows[] = array( $p, $scan );
		}
		?>
		<div class="zarmumia-lift-card" id="zarmumia-lift-all">
			<h2><?php esc_html_e( 'All your pages', 'zarmumia-lift' ); ?></h2>
			<p>
				<?php
				echo esc_html(
					$checked
						/* translators: 1: pages checked, 2: all pages, 3: pages with something to fix. */
						? sprintf( __( '%1$s of %2$s pages checked. %3$s need a fix.', 'zarmumia-lift' ), number_format_i18n( $checked ), number_format_i18n( count( $pages ) ), number_format_i18n( $todo ) )
						: __( 'Lift can check every page on your site, one after the other. It takes about a second per page.', 'zarmumia-lift' )
				);
				?>
			</p>
			<p>
				<button type="button" class="button button-primary" id="zarmumia-lift-check-all"><?php esc_html_e( 'Check all pages', 'zarmumia-lift' ); ?></button>
				<span class="zarmumia-lift-muted" id="zarmumia-lift-all-status"></span>
			</p>
			<?php if ( $pages ) : ?>
				<table class="widefat striped zarmumia-lift-pages">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'Page', 'zarmumia-lift' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Score', 'zarmumia-lift' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Description for Google', 'zarmumia-lift' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Image descriptions', 'zarmumia-lift' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Main heading', 'zarmumia-lift' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Questions and answers', 'zarmumia-lift' ); ?></th>
							<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Fix', 'zarmumia-lift' ); ?></span></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $rows as list( $p, $scan ) ) : ?>
							<?php
							$link  = add_query_arg(
								array(
									'page'    => Readiness::PAGE_SLUG,
									'page_id' => (int) $p->ID,
								),
								admin_url( 'admin.php' )
							);
							$title = '' !== trim( $p->post_title ) ? $p->post_title : __( '(no title)', 'zarmumia-lift' );
							?>
							<tr<?php echo (int) $p->ID === (int) $current ? ' class="is-current"' : ''; ?>>
								<td><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a>
									<?php if ( (int) $p->ID === Page_Fixes::front_id() ) : ?>
										<span class="zarmumia-lift-muted"><?php esc_html_e( '(home page)', 'zarmumia-lift' ); ?></span>
									<?php endif; ?>
								</td>
								<td><?php echo $scan ? esc_html( number_format_i18n( (int) $scan['score'] ) ) : '<span class="zarmumia-lift-muted">' . esc_html__( 'Not checked yet', 'zarmumia-lift' ) . '</span>'; ?></td>
								<?php
								self::cell( $scan, 'description' );
								self::cell( $scan, 'alt' );
								self::cell( $scan, 'h1' );
								self::cell( $scan, 'faq' );
								?>
								<td><a class="button button-small" href="<?php echo esc_url( $link . '#' . Page_Fixes::ANCHOR ); ?>"><?php esc_html_e( 'Fix', 'zarmumia-lift' ); ?></a></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p><?php esc_html_e( 'No published pages were found.', 'zarmumia-lift' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}
}
