<?php
/**
 * Admin menu and screens.
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the Lift menu and renders its (for now, placeholder) screen.
 */
class Admin {

	const CAPABILITY    = 'manage_options';
	const MENU_SLUG     = 'zarmumia-lift';
	const SCHEMA_SLUG   = 'zarmumia-lift-schema';   // Full version screen (includes/pro).
	const CRAWLERS_SLUG = 'zarmumia-lift-crawlers'; // Full version screen (includes/pro).

	/**
	 * Link to a full-version screen: the screen itself in the full version, the Lift page in the free one.
	 *
	 * @param string $slug Screen slug.
	 * @return string
	 */
	public static function pro_link( $slug ) {
		return ZARMUMIA_LIFT_PRO ? admin_url( 'admin.php?page=' . $slug ) : ZARMUMIA_LIFT_UPGRADE_URL;
	}

	/**
	 * Small "In the full version" tag, linking to the Lift page. Only in the free version.
	 */
	public static function pro_tag() {
		if ( ZARMUMIA_LIFT_PRO ) {
			return;
		}
		printf(
			'<a class="zarmumia-lift-pro-tag" href="%s" target="_blank" rel="noopener">%s</a>',
			esc_url( ZARMUMIA_LIFT_UPGRADE_URL ),
			esc_html__( 'In the full version', 'zarmumia-lift' )
		);
	}

	/**
	 * Small "In the Whole site package" tag. Only in the Landing page package (the free version shows pro_tag).
	 */
	public static function site_tag() {
		if ( ! ZARMUMIA_LIFT_PRO || ZARMUMIA_LIFT_SITE ) {
			return;
		}
		printf(
			'<a class="zarmumia-lift-pro-tag" href="%s" target="_blank" rel="noopener">%s</a>',
			esc_url( ZARMUMIA_LIFT_UPGRADE_URL ),
			esc_html__( 'In the Whole site package', 'zarmumia-lift' )
		);
	}

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_styles' ) );
	}

	/**
	 * Top-level "Lift" menu item.
	 */
	public static function register_menu() {
		add_menu_page(
			__( 'Lift by Zarmumia', 'zarmumia-lift' ),
			__( 'Lift', 'zarmumia-lift' ),
			self::CAPABILITY,
			self::MENU_SLUG,
			array( __CLASS__, 'render_page' ),
			'dashicons-chart-line',
			81
		);
		add_submenu_page(
			self::MENU_SLUG,
			__( 'Lift by Zarmumia', 'zarmumia-lift' ),
			__( 'Overview', 'zarmumia-lift' ),
			self::CAPABILITY,
			self::MENU_SLUG,
			array( __CLASS__, 'render_page' )
		);
		add_submenu_page(
			self::MENU_SLUG,
			__( 'Your AI readiness', 'zarmumia-lift' ),
			__( 'Readiness score', 'zarmumia-lift' ),
			self::CAPABILITY,
			Readiness::PAGE_SLUG,
			array( Readiness::class, 'render' )
		);
		add_submenu_page(
			self::MENU_SLUG,
			__( 'llms.txt', 'zarmumia-lift' ),
			__( 'llms.txt', 'zarmumia-lift' ),
			self::CAPABILITY,
			Llms::PAGE_SLUG,
			array( Llms::class, 'render' )
		);
		if ( ! ZARMUMIA_LIFT_PRO ) {
			return; // The free version has no screens for the full-version features.
		}
		add_submenu_page(
			self::MENU_SLUG,
			__( 'Business details for search and AI engines', 'zarmumia-lift' ),
			__( 'Schema', 'zarmumia-lift' ),
			self::CAPABILITY,
			self::SCHEMA_SLUG,
			array( __NAMESPACE__ . '\Schema', 'render' )
		);
		add_submenu_page(
			self::MENU_SLUG,
			__( 'AI crawlers and sitemap', 'zarmumia-lift' ),
			__( 'Crawlers and sitemap', 'zarmumia-lift' ),
			self::CAPABILITY,
			self::CRAWLERS_SLUG,
			array( __NAMESPACE__ . '\Crawlers', 'render' )
		);
	}

	/**
	 * Load the admin stylesheet only on Lift's own screens.
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public static function enqueue_styles( $hook_suffix ) {
		if ( ! preg_match( '/_page_' . preg_quote( self::MENU_SLUG, '/' ) . '(-[a-z]+)?$/', (string) $hook_suffix ) ) { // Only Lift's own screens.
			return;
		}
		wp_enqueue_style(
			'zarmumia-lift-admin',
			ZARMUMIA_LIFT_URL . 'assets/admin.css',
			array(),
			ZARMUMIA_LIFT_VERSION
		);
	}

	/**
	 * Main Lift screen: the wizard when a step is requested, otherwise start or summary.
	 */
	public static function render_page() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation.
		$step = isset( $_GET['step'] ) ? sanitize_key( wp_unslash( $_GET['step'] ) ) : '';
		if ( in_array( $step, Wizard::steps(), true ) ) {
			Wizard::render( $step );
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flag after redirect.
		$saved = isset( $_GET['saved'] );
		?>
		<div class="wrap zarmumia-lift">
			<h1><?php esc_html_e( 'Lift by Zarmumia', 'zarmumia-lift' ); ?></h1>

			<?php if ( ! ZARMUMIA_LIFT_PRO ) : ?>
				<p class="zarmumia-lift-edition">
					<?php esc_html_e( 'Free version: the readiness score and llms.txt.', 'zarmumia-lift' ); ?>
					<a href="<?php echo esc_url( ZARMUMIA_LIFT_UPGRADE_URL ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'What the full version adds', 'zarmumia-lift' ); ?></a>
				</p>
			<?php elseif ( ! ZARMUMIA_LIFT_SITE ) : ?>
				<p class="zarmumia-lift-edition">
					<?php esc_html_e( 'Landing page package: everything for the whole site, and checks and fixes for one page.', 'zarmumia-lift' ); ?>
					<a href="<?php echo esc_url( ZARMUMIA_LIFT_UPGRADE_URL ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'What the Whole site package adds', 'zarmumia-lift' ); ?></a>
				</p>
			<?php endif; ?>

			<?php if ( $saved ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Your business details were saved.', 'zarmumia-lift' ); ?></p></div>
			<?php endif; ?>

			<?php if ( Business::is_complete() ) : ?>
				<?php self::render_checklist(); ?>
				<p class="zarmumia-lift-edition">
					<?php if ( Updater::auto_updates_on() ) : ?>
						<?php esc_html_e( 'Automatic updates are on: every improvement to Lift reaches your site by itself.', 'zarmumia-lift' ); ?>
					<?php else : ?>
						<?php esc_html_e( 'Automatic updates are off. We recommend turning them on, so you always have the latest Lift:', 'zarmumia-lift' ); ?>
						<a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>"><?php esc_html_e( 'Plugins → "Enable auto-updates" next to Lift', 'zarmumia-lift' ); ?></a>
					<?php endif; ?>
				</p>
				<?php self::render_summary(); ?>
			<?php else : ?>
				<div class="zarmumia-lift-card">
					<h2><?php esc_html_e( 'Lift is installed', 'zarmumia-lift' ); ?></h2>
					<p><?php esc_html_e( 'Nothing on your site has changed. Your page looks exactly as it did before.', 'zarmumia-lift' ); ?></p>
					<p><?php esc_html_e( 'A few short questions about your business (about 3 minutes). Some answers are already filled in from your site.', 'zarmumia-lift' ); ?></p>
					<p><a class="button button-primary button-hero" href="<?php echo esc_url( Wizard::url( 'business' ) ); ?>"><?php esc_html_e( 'Start', 'zarmumia-lift' ); ?></a></p>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * "Getting started" checklist: the five steps, each with its state and a link.
	 */
	private static function render_checklist() {
		$llms  = Llms::state();
		$scan  = get_option( Readiness::OPTION );
		$robot = Robots::status();
		$pro   = ZARMUMIA_LIFT_PRO;
		// [ text, done, link, full version only ].
		$steps = array(
			array( __( 'Answer the short questions about your business', 'zarmumia-lift' ), true, Wizard::url( 'business' ), false ),
			array( __( 'Read and publish your llms.txt', 'zarmumia-lift' ), ! empty( $llms['published'] ) || (bool) Llms::detect_other(), admin_url( 'admin.php?page=' . Llms::PAGE_SLUG ), false ),
			array( __( 'Turn on business details for search and AI engines', 'zarmumia-lift' ), $pro && Schema::is_enabled(), self::pro_link( self::SCHEMA_SLUG ), true ),
			array( __( 'Check who can read your site', 'zarmumia-lift' ), $pro && ! in_array( false, $robot['search'], true ), self::pro_link( self::CRAWLERS_SLUG ), true ),
			array( __( 'Check your readiness score and fix what is easy', 'zarmumia-lift' ), is_array( $scan ) && (int) $scan['score'] >= 80, admin_url( 'admin.php?page=' . Readiness::PAGE_SLUG ), false ),
		);
		$mine  = $pro ? $steps : array_filter( $steps, function ( $s ) { return ! $s[3]; } ); // Steps this version can do.
		$done  = count( array_filter( wp_list_pluck( $mine, 1 ) ) );
		?>
		<div class="zarmumia-lift-card">
			<h2><?php esc_html_e( 'Getting started', 'zarmumia-lift' ); ?></h2>
			<p class="zarmumia-lift-muted">
				<?php
				/* translators: 1: steps done, 2: total steps. */
				echo esc_html( sprintf( __( '%1$s of %2$s steps done. About 10 minutes in total.', 'zarmumia-lift' ), number_format_i18n( $done ), number_format_i18n( count( $mine ) ) ) );
				?>
			</p>
			<ol class="zarmumia-lift-checks zarmumia-lift-start">
				<?php foreach ( $steps as $step ) : ?>
					<?php $locked = $step[3] && ! $pro; ?>
					<li class="<?php echo $locked ? 'is-locked' : ( $step[1] ? 'is-pass' : 'is-todo' ); ?>">
						<span class="zarmumia-lift-dot"></span>
						<?php if ( $locked ) : ?>
							<span><?php echo esc_html( $step[0] ); ?></span>
							<?php self::pro_tag(); ?>
						<?php else : ?>
							<a href="<?php echo esc_url( $step[2] ); ?>"><?php echo esc_html( $step[0] ); ?></a>
							<?php if ( $step[1] ) : ?>
								<span class="zarmumia-lift-muted"><?php esc_html_e( 'done', 'zarmumia-lift' ); ?></span>
							<?php endif; ?>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ol>
		</div>
		<?php
	}

	/**
	 * Summary of the saved business details.
	 */
	private static function render_summary() {
		$data      = Business::get();
		$langs     = array_intersect_key( Business::language_choices(), array_flip( $data['languages'] ) );
		$link_list = array_filter( $data['links'] );
		$rows      = array(
			__( 'Business name', 'zarmumia-lift' )            => $data['name'],
			__( 'What the business does', 'zarmumia-lift' )   => $data['description'],
			__( 'Owner or founder', 'zarmumia-lift' )         => trim( $data['founder_name'] . ( $data['founder_role'] ? ' · ' . $data['founder_role'] : '' ) ),
			__( 'City', 'zarmumia-lift' )                     => $data['city'],
			__( 'Service area', 'zarmumia-lift' )             => $data['area'],
			__( 'Languages', 'zarmumia-lift' )                => implode( ', ', $langs ),
			__( 'Phone', 'zarmumia-lift' )                    => $data['phone'],
			__( 'Email', 'zarmumia-lift' )                    => $data['email'],
			__( 'Links', 'zarmumia-lift' )                    => (string) count( $link_list ),
			__( 'Important pages', 'zarmumia-lift' )          => (string) count( $data['pages'] ),
			__( 'Logo', 'zarmumia-lift' )                     => $data['logo'] ? __( 'Chosen', 'zarmumia-lift' ) : ( Wizard::site_logo_url() ? __( 'From your site', 'zarmumia-lift' ) : '' ),
		);
		?>
		<div class="zarmumia-lift-card">
			<h2><?php esc_html_e( 'Your business details', 'zarmumia-lift' ); ?></h2>
			<table class="zarmumia-lift-summary">
				<?php foreach ( $rows as $label => $value ) : ?>
					<tr>
						<th scope="row"><?php echo esc_html( $label ); ?></th>
						<td><?php echo '' === $value ? '<span class="zarmumia-lift-muted">' . esc_html__( 'Not filled in', 'zarmumia-lift' ) . '</span>' : esc_html( $value ); ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
			<p><a class="button" href="<?php echo esc_url( Wizard::url( 'business' ) ); ?>"><?php esc_html_e( 'Edit details', 'zarmumia-lift' ); ?></a></p>
			<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=' . Llms::PAGE_SLUG ) ); ?>"><?php esc_html_e( 'Next: your llms.txt', 'zarmumia-lift' ); ?></a></p>
			<?php $scan = get_option( Readiness::OPTION ); ?>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=' . Readiness::PAGE_SLUG ) ); ?>">
					<?php
					echo is_array( $scan )
						/* translators: %s: readiness score 0-100. */
						? esc_html( sprintf( __( 'Your AI readiness score: %s', 'zarmumia-lift' ), number_format_i18n( (int) $scan['score'] ) ) )
						: esc_html__( 'Check your AI readiness', 'zarmumia-lift' );
					?>
				</a>
			</p>
		</div>
		<?php
	}
}
