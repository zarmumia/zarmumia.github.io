<?php
/**
 * Update by click (decided 9.11.2026): WordPress shows "There is a new version of Lift" and updates in one click.
 *
 * How: once in a while Lift reads a small public file on zarmumia.co.il with the latest version number.
 * Nothing about the site is sent: not its address, not its content (a plain user agent, no site URL).
 * The download address of each paid package is written only inside that package's own files
 * (includes/pro, includes/site), so the free version does not know it ("secret address per package").
 *
 * Signed updates (after the outside code review, 9.11.2026): every zip is signed with Fanny's private Ed25519 key,
 * which never leaves her computer. Lift installs an update only if the signature matches the public key below,
 * so even someone who takes over zarmumia.co.il cannot push a fake update.
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Updates from zarmumia.co.il.
 */
class Updater {

	const SLUG      = 'zarmumia-lift';
	const CACHE     = 'zarmumia_lift_update_info'; // Transient (removed on uninstall with the other zarmumia_lift_ data).
	const CACHE_TTL = 43200;                         // 12 hours.

	/**
	 * Public half of the signing key (base64). The private half is only on Fanny's computer.
	 */
	const PUBLIC_KEY = 'bRMn3mvXAJ/9/RNin/bY8ZOjqAMT3NEGdRQcDML7lpM=';

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'add_update' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'details' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'clear_cache' ), 10, 0 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verified_download' ), 10, 3 );
		add_action( 'admin_init', array( __CLASS__, 'auto_updates_once' ) );
	}

	/**
	 * Where updates come from. A test site may point elsewhere by defining ZARMUMIA_LIFT_UPDATE_BASE.
	 *
	 * @return string
	 */
	private static function base() {
		return defined( 'ZARMUMIA_LIFT_UPDATE_BASE' ) ? untrailingslashit( ZARMUMIA_LIFT_UPDATE_BASE ) : 'https://zarmumia.co.il';
	}

	/**
	 * This copy's package: free or site (Lift). The landing page package was retired before it was ever sold,
	 * so a copy without includes/site gets no updates (empty string).
	 *
	 * @return string
	 */
	public static function edition() {
		return ZARMUMIA_LIFT_SITE ? 'site' : ( ZARMUMIA_LIFT_PRO ? '' : 'free' );
	}

	/**
	 * Download folder of this package. The paid ones come from the paid files themselves.
	 *
	 * @return string
	 */
	private static function folder() {
		if ( ZARMUMIA_LIFT_SITE ) {
			return Site_Pages::DOWNLOADS;
		}
		if ( ZARMUMIA_LIFT_PRO ) {
			return Page_Fixes::DOWNLOADS;
		}
		return 'free';
	}

	/**
	 * Latest version info from zarmumia.co.il (cached). Sends nothing about this site.
	 *
	 * @return array|null { version, requires, requires_php, tested, changelog }
	 */
	public static function info() {
		$cached = get_site_transient( self::CACHE );
		if ( is_array( $cached ) ) {
			return $cached ? $cached : null;
		}
		$response = wp_remote_get(
			self::base() . '/lift/update/version.json',
			array(
				'timeout'    => 8,
				'user-agent' => 'Lift-by-Zarmumia-updater', // No site address, unlike WordPress's default.
				'headers'    => array( 'Accept' => 'application/json' ),
			)
		);
		$data = null;
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$json = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( is_array( $json ) && ! empty( $json['version'] ) && preg_match( '/^[0-9][0-9a-z.\-]*$/i', (string) $json['version'] ) ) {
				$data = array(
					'version'      => (string) $json['version'],
					'requires'     => (string) ( $json['requires'] ?? '' ),
					'requires_php' => (string) ( $json['requires_php'] ?? '' ),
					'tested'       => (string) ( $json['tested'] ?? '' ),
					'changelog'    => array_map( 'strval', (array) ( $json['changelog'] ?? array() ) ),
					'signatures'   => array_map( 'strval', (array) ( $json['signatures'] ?? array() ) ),
				);
			}
		}
		// Remember failures too (as an empty array), so a site never asks more than twice a day.
		set_site_transient( self::CACHE, $data ? $data : array(), self::CACHE_TTL );
		return $data;
	}

	/**
	 * Download address of a version of this package.
	 *
	 * @param string $version Version.
	 * @return string
	 */
	private static function package_url( $version ) {
		return self::base() . '/lift/dl/' . self::folder() . '/zarmumia-lift-' . self::edition() . '-' . rawurlencode( $version ) . '.zip';
	}

	/**
	 * Tell WordPress when a newer version exists.
	 *
	 * @param object $transient Update data.
	 * @return object
	 */
	public static function add_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$info = self::info();
		$file = plugin_basename( ZARMUMIA_LIFT_FILE );
		$item = (object) array(
			'id'           => 'zarmumia.co.il/lift',
			'slug'         => self::SLUG,
			'plugin'       => $file,
			'new_version'  => $info ? $info['version'] : ZARMUMIA_LIFT_VERSION,
			'url'          => 'https://zarmumia.co.il/lift/',
			'package'      => $info ? self::package_url( $info['version'] ) : '',
			'requires'     => $info ? $info['requires'] : '',
			'requires_php' => $info ? $info['requires_php'] : '',
			'tested'       => $info ? $info['tested'] : '',
			'icons'        => array( 'default' => ZARMUMIA_LIFT_URL . 'assets/gecko_teal.png' ),
		);
		if ( $info && '' !== self::edition() && version_compare( $info['version'], ZARMUMIA_LIFT_VERSION, '>' ) ) {
			$transient->response[ $file ] = $item;
		} else {
			$transient->no_update[ $file ] = $item; // Also enables the "auto-updates" link for Lift.
		}
		return $transient;
	}

	/**
	 * "View details" window for Lift.
	 *
	 * @param false|object|array $result Result.
	 * @param string             $action Action.
	 * @param object             $args   Arguments.
	 * @return false|object|array
	 */
	public static function details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$info = self::info();
		if ( ! $info ) {
			return $result;
		}
		$changes = '<ul>';
		foreach ( $info['changelog'] as $line ) {
			$changes .= '<li>' . esc_html( $line ) . '</li>';
		}
		$changes .= '</ul>';
		return (object) array(
			'name'          => 'Lift by Zarmumia',
			'slug'          => self::SLUG,
			'version'       => $info['version'],
			'author'        => '<a href="https://zarmumia.co.il/">Zarmumia</a>',
			'homepage'      => 'https://zarmumia.co.il/lift/',
			'requires'      => $info['requires'],
			'requires_php'  => $info['requires_php'],
			'tested'        => $info['tested'],
			'download_link' => self::package_url( $info['version'] ),
			'sections'      => array(
				'description' => esc_html__( 'Makes a working landing page ready to be read by AI engines, without changing its design or content.', 'zarmumia-lift' ),
				'changelog'   => $changes,
			),
		);
	}

	/**
	 * Download a Lift update ourselves and install it only if Fanny's signature on it is valid.
	 * Other plugins' downloads are left to WordPress.
	 *
	 * @param bool|\WP_Error|string $reply   Earlier result (false = let WordPress download).
	 * @param string                $package Download address.
	 * @param object                $upgrader Upgrader.
	 * @return bool|\WP_Error|string Path of the verified file, or an error.
	 */
	public static function verified_download( $reply, $package, $upgrader ) {
		if ( false !== $reply || ! is_string( $package ) || 0 !== strpos( $package, self::base() . '/lift/dl/' ) ) {
			return $reply;
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$file = download_url( $package, 120 );
		if ( is_wp_error( $file ) ) {
			return $file;
		}
		if ( self::signature_ok( $file, self::info() ) ) {
			return $file;
		}
		// Maybe a newer version was published since the last check: ask again once.
		self::clear_cache();
		if ( self::signature_ok( $file, self::info() ) ) {
			return $file;
		}
		wp_delete_file( $file );
		return new \WP_Error( 'zarmumia_lift_bad_signature', __( 'Lift did not install this update: its signature could not be verified. Your site was not changed. Please try again later.', 'zarmumia-lift' ) );
	}

	/**
	 * Is the file signed with Fanny's key, for this package and version?
	 *
	 * @param string     $file Downloaded file.
	 * @param array|null $info Version info.
	 * @return bool
	 */
	private static function signature_ok( $file, $info ) {
		$edition = self::edition();
		if ( ! $info || '' === $edition || empty( $info['signatures'][ $edition ] ) || ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return false;
		}
		$signature = base64_decode( $info['signatures'][ $edition ], true );
		$key       = base64_decode( self::PUBLIC_KEY, true );
		$data      = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local temp file.
		if ( false === $signature || false === $key || false === $data ) {
			return false;
		}
		try {
			return sodium_crypto_sign_verify_detached( $signature, $data, $key );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/**
	 * Automatic updates on by default (decided 10.11.2026: updates are what Lift promises). Done ONCE: if the
	 * site owner later turns them off in the plugins list, Lift never turns them back on.
	 */
	public static function auto_updates_once() {
		if ( get_option( ZARMUMIA_LIFT_OPTION_PREFIX . 'auto_updates_set' ) || ! current_user_can( 'update_plugins' ) ) {
			return;
		}
		if ( function_exists( 'wp_is_auto_update_enabled_for_type' ) && wp_is_auto_update_enabled_for_type( 'plugin' ) ) {
			$list = (array) get_site_option( 'auto_update_plugins', array() );
			$file = plugin_basename( ZARMUMIA_LIFT_FILE );
			if ( ! in_array( $file, $list, true ) ) {
				$list[] = $file;
				update_site_option( 'auto_update_plugins', $list );
			}
		}
		update_option( ZARMUMIA_LIFT_OPTION_PREFIX . 'auto_updates_set', 1, false );
	}

	/**
	 * Are automatic updates on for Lift right now?
	 *
	 * @return bool
	 */
	public static function auto_updates_on() {
		return in_array( plugin_basename( ZARMUMIA_LIFT_FILE ), (array) get_site_option( 'auto_update_plugins', array() ), true );
	}

	/**
	 * After an update, check again next time instead of using the old answer.
	 */
	public static function clear_cache() {
		delete_site_transient( self::CACHE );
	}
}
