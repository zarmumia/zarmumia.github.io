<?php
/**
 * Reads robots.txt and finds the sitemap. Read-only: it never changes anything on the site.
 * Used by the readiness check (free) and by the crawlers screen (full version).
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Who may read the site, and where the sitemap is.
 */
class Robots {

	const ROBOTS_CACHE = 'zarmumia_lift_robots_seen';

	/**
	 * Crawler groups.
	 *
	 * @return array group => [ bot tokens ]
	 */
	public static function groups() {
		return array(
			'search'   => array( 'OAI-SearchBot', 'ChatGPT-User', 'Claude-SearchBot', 'Claude-User', 'PerplexityBot', 'Perplexity-User' ),
			'training' => array( 'GPTBot', 'ClaudeBot', 'Google-Extended', 'CCBot', 'Applebot-Extended', 'Meta-ExternalAgent' ),
			'classic'  => array( 'Googlebot', 'Bingbot' ),
		);
	}

	/**
	 * Path of a real robots.txt file, if the site has one (it replaces WordPress's robots.txt entirely).
	 *
	 * @return string Empty when there is none.
	 */
	public static function physical_file() {
		$file = trailingslashit( ABSPATH ) . 'robots.txt';
		if ( function_exists( 'get_home_path' ) ) {
			$file = trailingslashit( get_home_path() ) . 'robots.txt';
		}
		return file_exists( $file ) ? $file : '';
	}

	/**
	 * The robots.txt visitors get: the real file if there is one, otherwise what WordPress builds (same steps as core).
	 *
	 * @return string
	 */
	public static function effective_robots() {
		$file = self::physical_file();
		if ( $file ) {
			return (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file.
		}

		// Best: ask the site for its real robots.txt (some SEO plugins add their lines only for visitors).
		// Some servers cannot call themselves; then fall back to building it like WordPress does.
		$cached = get_transient( self::ROBOTS_CACHE );
		if ( is_string( $cached ) && '' !== $cached ) {
			return $cached;
		}
		if ( false === $cached ) {
			$response = wp_remote_get( home_url( '/robots.txt' ), array( 'timeout' => 2, 'redirection' => 1, 'sslverify' => false ) );
			if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
				$body = (string) wp_remote_retrieve_body( $response );
				set_transient( self::ROBOTS_CACHE, $body, HOUR_IN_SECONDS );
				return $body;
			}
			set_transient( self::ROBOTS_CACHE, '', HOUR_IN_SECONDS ); // Remember that the site cannot call itself.
		}
		return self::built_robots();
	}

	/**
	 * robots.txt built the same way WordPress core builds it (admin-side view).
	 *
	 * @return string
	 */
	protected static function built_robots() {
		$public = (string) get_option( 'blog_public' );
		$output = "User-agent: *\n";
		if ( '0' === $public ) {
			$output .= "Disallow: /\n";
		} else {
			$path    = (string) wp_parse_url( site_url(), PHP_URL_PATH );
			$output .= "Disallow: $path/wp-admin/\n";
			$output .= "Allow: $path/wp-admin/admin-ajax.php\n";
		}
		return (string) apply_filters( 'robots_txt', $output, $public ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WordPress core hook.
	}

	/**
	 * Parse robots.txt into groups of [ agents[], rules[] ].
	 *
	 * @param string $text Robots text.
	 * @return array
	 */
	public static function parse( $text ) {
		$groups  = array();
		$current = null;
		$last    = '';
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			$line = trim( preg_replace( '/#.*$/', '', $line ) );
			if ( '' === $line || false === strpos( $line, ':' ) ) {
				continue;
			}
			list( $key, $value ) = array_map( 'trim', explode( ':', $line, 2 ) );
			$key = strtolower( $key );
			if ( 'user-agent' === $key ) {
				if ( 'agent' !== $last || null === $current ) {
					$groups[] = array( 'agents' => array(), 'rules' => array() );
					$current  = count( $groups ) - 1;
				}
				$groups[ $current ]['agents'][] = strtolower( $value );
				$last                            = 'agent';
			} elseif ( in_array( $key, array( 'allow', 'disallow' ), true ) && null !== $current ) {
				$groups[ $current ]['rules'][] = array( $key, $value );
				$last                           = 'rule';
			}
		}
		return $groups;
	}

	/**
	 * May this bot read the home page ("/")? Google's rules: the bot's own group if there is one, else "*";
	 * the longest matching rule wins; on a tie, Allow wins.
	 *
	 * @param array  $groups Parsed groups.
	 * @param string $bot    Bot token.
	 * @return bool
	 */
	public static function is_allowed( array $groups, $bot ) {
		$bot   = strtolower( $bot );
		$rules = array();
		foreach ( $groups as $g ) {
			if ( in_array( $bot, $g['agents'], true ) ) {
				$rules = array_merge( $rules, $g['rules'] );
			}
		}
		if ( ! $rules ) {
			foreach ( $groups as $g ) {
				if ( in_array( '*', $g['agents'], true ) ) {
					$rules = array_merge( $rules, $g['rules'] );
				}
			}
		}
		$best_len = -1;
		$allowed  = true;
		foreach ( $rules as $rule ) {
			list( $type, $path ) = $rule;
			if ( '' === $path ) {
				continue; // "Disallow:" with nothing = allow everything.
			}
			$prefix = rtrim( str_replace( '*', '', $path ), '$' );
			if ( '' !== $prefix && '/' !== $prefix ) {
				continue; // Rule is about another path (like /wp-admin/), not the home page.
			}
			$len = strlen( $path );
			if ( $len > $best_len || ( $len === $best_len && 'allow' === $type ) ) {
				$best_len = $len;
				$allowed  = ( 'allow' === $type );
			}
		}
		return $allowed;
	}

	/**
	 * Status of every crawler: group => [ bot => allowed ].
	 *
	 * @return array
	 */
	public static function status() {
		$groups = self::parse( self::effective_robots() );
		$out    = array();
		foreach ( self::groups() as $key => $bots ) {
			foreach ( $bots as $bot ) {
				$out[ $key ][ $bot ] = self::is_allowed( $groups, $bot );
			}
		}
		return $out;
	}

	/**
	 * Where is the sitemap, and who makes it.
	 *
	 * @return string URL, or empty when none was found.
	 */
	public static function sitemap_url() {
		$info = self::sitemap_info();
		return $info['url'];
	}

	/**
	 * Is Rank Math installed AND working? Until its first setup ("connect an account or skip") is done,
	 * Rank Math outputs nothing on the site (no business details, no sitemap, no description), so Lift
	 * treats it as if there were no SEO plugin (found in testing, 9.11.2026).
	 *
	 * @return bool
	 */
	public static function rank_math_ready() {
		if ( ! class_exists( '\RankMath\Helper' ) ) {
			return false;
		}
		return ! ( is_callable( array( '\RankMath\Helper', 'is_invalid_registration' ) ) && \RankMath\Helper::is_invalid_registration() );
	}

	/**
	 * Sitemap URL and source.
	 *
	 * @return array { url, source }
	 */
	public static function sitemap_info() {
		if ( defined( 'WPSEO_VERSION' ) && class_exists( '\WPSEO_Options' ) && \WPSEO_Options::get( 'enable_xml_sitemap' ) ) {
			return array( 'url' => home_url( '/sitemap_index.xml' ), 'source' => 'Yoast SEO' );
		}
		if ( self::rank_math_ready() && \RankMath\Helper::is_module_active( 'sitemap' ) ) {
			return array( 'url' => home_url( '/sitemap_index.xml' ), 'source' => 'Rank Math' );
		}
		if ( function_exists( 'aioseo' ) && isset( aioseo()->options->sitemap->general->enable ) && aioseo()->options->sitemap->general->enable ) {
			return array( 'url' => home_url( '/sitemap.xml' ), 'source' => 'All in One SEO' );
		}
		if ( function_exists( 'wp_sitemaps_get_server' ) && wp_sitemaps_get_server()->sitemaps_enabled() ) {
			return array( 'url' => home_url( '/wp-sitemap.xml' ), 'source' => 'WordPress' );
		}
		// Fall back to a Sitemap line already in robots.txt.
		if ( preg_match( '/^\s*Sitemap:\s*(\S+)/mi', self::effective_robots_without_lift(), $m ) ) {
			return array( 'url' => $m[1], 'source' => __( 'robots.txt', 'zarmumia-lift' ) );
		}
		return array( 'url' => '', 'source' => '' );
	}

	/**
	 * robots.txt as it would be without Lift's block (to judge what others already provide).
	 *
	 * @return string
	 */
	protected static function effective_robots_without_lift() {
		if ( self::physical_file() ) {
			return self::effective_robots();
		}
		$lift = array( __NAMESPACE__ . '\\Crawlers', 'filter_robots' ); // Only in the full version.
		$had  = false !== has_filter( 'robots_txt', $lift );
		remove_filter( 'robots_txt', $lift, 99999 );
		$text = self::built_robots();
		if ( $had ) {
			add_filter( 'robots_txt', $lift, 99999, 2 );
		}
		return $text;
	}

	/**
	 * Is the sitemap listed in robots.txt / in the published llms.txt?
	 *
	 * @param string $url Sitemap URL.
	 * @return array { robots: bool, llms: bool|null } (llms null when llms.txt is not published by Lift)
	 */
	public static function sitemap_mentions( $url ) {
		$robots = $url && false !== stripos( self::effective_robots(), $url );
		// Yoast, Rank Math and All in One SEO list their own sitemap in the WordPress robots.txt for visitors,
		// even when the admin-side view cannot see it.
		if ( ! $robots && $url && ! self::physical_file() && in_array( self::sitemap_info()['source'], array( 'Yoast SEO', 'Rank Math', 'All in One SEO', 'WordPress' ), true ) ) {
			$robots = true;
		}
		$llms = Llms::state();
		return array(
			'robots' => $robots,
			'llms'   => empty( $llms['published'] ) ? null : ( $url && false !== strpos( Llms::current_sitemap_link( $llms['content'] ), $url ) ),
		);
	}
}
