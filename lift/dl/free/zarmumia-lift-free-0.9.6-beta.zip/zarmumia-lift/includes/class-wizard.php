<?php
/**
 * Setup wizard: four short screens about the business.
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the wizard screens and saves each step.
 */
class Wizard {

	const ACTION = 'zarmumia_lift_save_step';

	/**
	 * Step keys, in order.
	 *
	 * @return array
	 */
	public static function steps() {
		return array( 'business', 'people', 'links', 'pages' );
	}

	/**
	 * Step titles.
	 *
	 * @return array
	 */
	public static function step_titles() {
		return array(
			'business' => __( 'Your business', 'zarmumia-lift' ),
			'people'   => __( 'People and place', 'zarmumia-lift' ),
			'links'    => __( 'Links', 'zarmumia-lift' ),
			'pages'    => __( 'Important pages', 'zarmumia-lift' ),
		);
	}

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	/**
	 * URL of a wizard step (or of the main Lift screen when $step is empty).
	 *
	 * @param string $step Step key.
	 * @param array  $args Extra query args.
	 * @return string
	 */
	public static function url( $step = '', array $args = array() ) {
		$query = array( 'page' => Admin::MENU_SLUG );
		if ( $step ) {
			$query['step'] = $step;
		}
		return add_query_arg( array_merge( $query, $args ), admin_url( 'admin.php' ) );
	}

	/**
	 * Save one step, then go to the next one.
	 */
	public static function handle_save() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}

		$step = isset( $_POST['step'] ) ? sanitize_key( wp_unslash( $_POST['step'] ) ) : '';
		if ( ! in_array( $step, self::steps(), true ) ) {
			wp_die( esc_html__( 'Unknown step.', 'zarmumia-lift' ) );
		}
		check_admin_referer( 'zarmumia_lift_step_' . $step );

		Business::save_step( $step, wp_unslash( $_POST ) ); // Each field is cleaned in Business::save_step().

		$steps = self::steps();
		$index = array_search( $step, $steps, true );
		$next  = $steps[ $index + 1 ] ?? '';

		wp_safe_redirect( $next ? self::url( $next ) : self::url( '', array( 'saved' => '1' ) ) );
		exit;
	}

	/**
	 * Render a wizard step.
	 *
	 * @param string $step Step key.
	 */
	public static function render( $step ) {
		$steps  = self::steps();
		$titles = self::step_titles();
		$index  = array_search( $step, $steps, true );
		$data   = Business::get();
		$prev   = $index > 0 ? $steps[ $index - 1 ] : '';
		$last   = count( $steps ) - 1 === $index;
		?>
		<div class="wrap zarmumia-lift">
			<h1><?php esc_html_e( 'Lift by Zarmumia', 'zarmumia-lift' ); ?></h1>

			<ol class="zarmumia-lift-steps">
				<?php foreach ( $steps as $i => $key ) : ?>
					<li class="<?php echo esc_attr( $i < $index ? 'is-done' : ( $i === $index ? 'is-current' : '' ) ); ?>">
						<span class="zarmumia-lift-steps__num"><?php echo esc_html( number_format_i18n( $i + 1 ) ); ?></span>
						<?php echo esc_html( $titles[ $key ] ); ?>
					</li>
				<?php endforeach; ?>
			</ol>

			<form class="zarmumia-lift-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
				<input type="hidden" name="step" value="<?php echo esc_attr( $step ); ?>" />
				<?php wp_nonce_field( 'zarmumia_lift_step_' . $step ); ?>

				<p class="zarmumia-lift-muted">
					<?php
					/* translators: 1: current step number, 2: total steps. */
					echo esc_html( sprintf( __( 'Step %1$s of %2$s', 'zarmumia-lift' ), number_format_i18n( $index + 1 ), number_format_i18n( count( $steps ) ) ) );
					?>
				</p>
				<h2><?php echo esc_html( $titles[ $step ] ); ?></h2>

				<?php
				switch ( $step ) {
					case 'business':
						self::fields_business( $data );
						break;
					case 'people':
						self::fields_people( $data );
						break;
					case 'links':
						self::fields_links( $data );
						break;
					case 'pages':
						self::fields_pages( $data );
						break;
				}
				?>

				<div class="zarmumia-lift-actions">
					<?php submit_button( $last ? __( 'Save and finish', 'zarmumia-lift' ) : __( 'Continue', 'zarmumia-lift' ), 'primary', 'submit', false ); ?>
					<?php if ( $prev ) : ?>
						<a class="button" href="<?php echo esc_url( self::url( $prev ) ); ?>"><?php esc_html_e( 'Back', 'zarmumia-lift' ); ?></a>
					<?php endif; ?>
				</div>
			</form>
		</div>
		<?php
	}

	/**
	 * A text input row.
	 *
	 * @param string $name  Field name.
	 * @param string $label Label.
	 * @param string $value Current value.
	 * @param string $help  Help text under the field.
	 * @param string $type  Input type.
	 */
	private static function text_field( $name, $label, $value, $help = '', $type = 'text' ) {
		$id = 'zarmumia-lift-' . str_replace( array( '[', ']' ), array( '-', '' ), $name );
		?>
		<p class="zarmumia-lift-field">
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
			<input type="<?php echo esc_attr( $type ); ?>" class="regular-text" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" />
			<?php if ( $help ) : ?>
				<span class="description"><?php echo esc_html( $help ); ?></span>
			<?php endif; ?>
		</p>
		<?php
	}

	/**
	 * Step 1: name and one sentence.
	 *
	 * @param array $data Business data.
	 */
	private static function fields_business( array $data ) {
		self::text_field( 'name', __( 'Business name', 'zarmumia-lift' ), $data['name'], __( 'Pre-filled from your site settings. Change it if needed.', 'zarmumia-lift' ) );
		?>
		<p class="zarmumia-lift-field">
			<label for="zarmumia-lift-description"><?php esc_html_e( 'What does the business do, in one sentence?', 'zarmumia-lift' ); ?></label>
			<textarea class="large-text" rows="3" id="zarmumia-lift-description" name="description"><?php echo esc_textarea( $data['description'] ); ?></textarea>
			<span class="description"><?php esc_html_e( 'Write it the way you would tell a new client. AI engines will use this sentence to understand you.', 'zarmumia-lift' ); ?></span>
		</p>
		<?php
		self::logo_field( (int) $data['logo'] );
	}

	/**
	 * The site's own logo (theme logo, else site icon), for when no logo was chosen in Lift.
	 *
	 * @return string URL or empty.
	 */
	public static function site_logo_url() {
		$id = (int) get_theme_mod( 'custom_logo' );
		if ( ! $id ) {
			$id = (int) get_option( 'site_logo' ); // Block themes.
		}
		$url = $id ? wp_get_attachment_image_url( $id, 'full' ) : '';
		return $url ? $url : (string) get_site_icon_url( 512 );
	}

	/**
	 * Business logo: chosen from the media library (decided 9.11.2026). Nothing is uploaded or changed on the site;
	 * Lift only remembers which image to use.
	 *
	 * @param int $logo Chosen image ID, 0 = none.
	 */
	private static function logo_field( $logo ) {
		$chosen = $logo ? wp_get_attachment_image_url( $logo, 'medium' ) : '';
		$site   = self::site_logo_url();
		$shown  = $chosen ? $chosen : $site;
		?>
		<div class="zarmumia-lift-field zarmumia-lift-logo">
			<label><?php esc_html_e( 'Business logo', 'zarmumia-lift' ); ?></label>
			<div class="zarmumia-lift-logo__box">
				<img id="zarmumia-lift-logo-preview" src="<?php echo esc_url( $shown ); ?>" alt="" <?php echo $shown ? '' : 'hidden'; ?> />
				<span id="zarmumia-lift-logo-none" class="zarmumia-lift-muted" <?php echo $shown ? 'hidden' : ''; ?>><?php esc_html_e( 'No logo yet', 'zarmumia-lift' ); ?></span>
			</div>
			<input type="hidden" name="logo" id="zarmumia-lift-logo" value="<?php echo (int) $logo; ?>" data-site="<?php echo esc_url( $site ); ?>" />
			<button type="button" class="button" id="zarmumia-lift-logo-choose"><?php esc_html_e( 'Choose a logo', 'zarmumia-lift' ); ?></button>
			<button type="button" class="button-link" id="zarmumia-lift-logo-remove" <?php echo $logo ? '' : 'hidden'; ?>><?php esc_html_e( 'Remove', 'zarmumia-lift' ); ?></button>
			<span class="description" id="zarmumia-lift-logo-help">
				<?php
				echo esc_html(
					$chosen || ! $site
						? __( 'Google and AI engines show it next to your business name. A square image works best.', 'zarmumia-lift' )
						: __( 'This is your site\'s logo, so Lift uses it. To use a different one, choose it here.', 'zarmumia-lift' )
				);
				?>
			</span>
		</div>
		<?php
	}

	/**
	 * Media library, only on the first wizard step (for the logo).
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public static function enqueue( $hook_suffix ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation.
		$step = isset( $_GET['step'] ) ? sanitize_key( wp_unslash( $_GET['step'] ) ) : '';
		if ( ! preg_match( '/_page_' . preg_quote( Admin::MENU_SLUG, '/' ) . '$/', (string) $hook_suffix ) || 'business' !== $step ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script( 'zarmumia-lift-logo', ZARMUMIA_LIFT_URL . 'assets/logo.js', array( 'jquery' ), ZARMUMIA_LIFT_VERSION, true );
		wp_localize_script(
			'zarmumia-lift-logo',
			'zarmumiaLiftLogo',
			array(
				'title'  => __( 'Choose your business logo', 'zarmumia-lift' ),
				'button' => __( 'Use this logo', 'zarmumia-lift' ),
			)
		);
	}

	/**
	 * Step 2: founder, area, languages, contact.
	 *
	 * @param array $data Business data.
	 */
	private static function fields_people( array $data ) {
		self::text_field( 'founder_name', __( 'Owner or founder name', 'zarmumia-lift' ), $data['founder_name'] );
		self::text_field( 'founder_role', __( 'Role', 'zarmumia-lift' ), $data['founder_role'], __( 'For example: Founder, Owner, CEO.', 'zarmumia-lift' ) );
		self::text_field( 'city', __( 'City', 'zarmumia-lift' ), $data['city'] );
		self::text_field( 'area', __( 'Service area', 'zarmumia-lift' ), $data['area'], __( 'Where you work. For example: Sharon area, all of Israel, online worldwide.', 'zarmumia-lift' ) );
		?>
		<fieldset class="zarmumia-lift-field">
			<legend><?php esc_html_e( 'Languages you work in', 'zarmumia-lift' ); ?></legend>
			<?php foreach ( Business::language_choices() as $code => $label ) : ?>
				<label class="zarmumia-lift-check">
					<input type="checkbox" name="languages[]" value="<?php echo esc_attr( $code ); ?>" <?php checked( in_array( $code, $data['languages'], true ) ); ?> />
					<?php echo esc_html( $label ); ?>
				</label>
			<?php endforeach; ?>
		</fieldset>
		<?php
		self::text_field( 'phone', __( 'Phone (optional)', 'zarmumia-lift' ), $data['phone'], __( 'Use the same number that appears on your page and on Google.', 'zarmumia-lift' ), 'tel' );
		self::text_field( 'email', __( 'Email (optional)', 'zarmumia-lift' ), $data['email'], '', 'email' );
	}

	/**
	 * Step 3: social and Google Business Profile links.
	 *
	 * @param array $data Business data.
	 */
	private static function fields_links( array $data ) {
		?>
		<p class="zarmumia-lift-muted"><?php esc_html_e( 'Paste only the links you have. Empty fields are fine.', 'zarmumia-lift' ); ?></p>
		<?php
		foreach ( Business::link_choices() as $key => $label ) {
			$help = 'google_business' === $key ? __( 'Your business page on Google Maps. It helps Google and AI engines connect your site to your business.', 'zarmumia-lift' ) : '';
			self::text_field( 'links[' . $key . ']', $label, $data['links'][ $key ] ?? '', $help, 'url' );
		}
	}

	/**
	 * Step 4: which pages matter.
	 *
	 * @param array $data Business data.
	 */
	private static function fields_pages( array $data ) {
		$pages = get_pages(
			array(
				'post_status' => 'publish',
				'sort_column' => 'menu_order,post_title',
				'number'      => 300,
			)
		);
		$front = (int) get_option( 'page_on_front' );
		?>
		<fieldset class="zarmumia-lift-field">
			<legend><?php esc_html_e( 'Which pages should AI engines know about?', 'zarmumia-lift' ); ?></legend>
			<?php if ( empty( $pages ) ) : ?>
				<p><?php esc_html_e( 'No published pages were found.', 'zarmumia-lift' ); ?></p>
			<?php endif; ?>
			<?php foreach ( $pages as $page ) : ?>
				<label class="zarmumia-lift-check zarmumia-lift-check--block">
					<input type="checkbox" name="pages[]" value="<?php echo esc_attr( $page->ID ); ?>" <?php checked( in_array( (int) $page->ID, array_map( 'intval', $data['pages'] ), true ) ); ?> />
					<?php echo esc_html( get_the_title( $page ) ); ?>
					<?php if ( $front === (int) $page->ID ) : ?>
						<span class="zarmumia-lift-tag"><?php esc_html_e( 'Home page', 'zarmumia-lift' ); ?></span>
					<?php endif; ?>
				</label>
			<?php endforeach; ?>
			<span class="description"><?php esc_html_e( 'Choose the pages that explain what you do: home, services, about, contact.', 'zarmumia-lift' ); ?></span>
		</fieldset>
		<?php
	}
}
