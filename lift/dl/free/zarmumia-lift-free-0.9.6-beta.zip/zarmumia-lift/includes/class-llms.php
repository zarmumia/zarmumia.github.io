<?php
/**
 * llms.txt: detect an existing one, build a draft from the business details, edit, publish, serve.
 *
 * Rule: never serve a second llms.txt. If another plugin or a real file already provides one, Lift only shows it.
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * llms.txt feature.
 */
class Llms {

	const OPTION    = 'zarmumia_lift_llms';
	const ACTION    = 'zarmumia_lift_llms';
	const PAGE_SLUG = 'zarmumia-lift-llms';
	const PROBE_ARG = 'zarmumia_lift_probe';
	const MAX_BYTES = 100000;
	const PROBE_CACHE = 'zarmumia_lift_llms_probe';

	/**
	 * Last line of the served file, so the owner (and Lift) can tell the file comes from Lift.
	 * An HTML comment: allowed in Markdown and hidden when the file is shown as formatted text.
	 */
	const SIGNATURE = '<!-- Created with Lift by Zarmumia -->';

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		add_action( 'parse_request', array( __CLASS__, 'maybe_serve' ), 0 );
		if ( is_admin() ) {
			add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_action' ) );
			add_action( 'admin_notices', array( __CLASS__, 'new_pages_notice' ) );
			add_action( 'admin_init', array( __CLASS__, 'remember_pages_once' ) );
		}
	}

	/**
	 * For an llms.txt published before Lift tracked pages: remember today's pages, so only later ones count as new.
	 */
	public static function remember_pages_once() {
		$state = self::state();
		if ( ! empty( $state['published'] ) && ! isset( $state['seen_pages'] ) && current_user_can( Admin::CAPABILITY ) ) {
			$state['seen_pages'] = self::published_page_ids();
			update_option( self::OPTION, $state, false );
		}
	}

	/**
	 * Saved state: draft text and whether it is published.
	 *
	 * @return array
	 */
	public static function state() {
		$state = get_option( self::OPTION, array() );
		return array_merge(
			array(
				'content'   => '',
				'published' => false,
				'updated'   => 0,
			),
			is_array( $state ) ? $state : array()
		);
	}

	/**
	 * Path of the llms.txt request for this site (works when WordPress lives in a subfolder).
	 *
	 * @return string
	 */
	private static function llms_path() {
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		return untrailingslashit( $home ) . '/llms.txt';
	}

	/**
	 * Serve /llms.txt, only when Lift's version is published and nothing else provides one.
	 */
	public static function maybe_serve() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public read-only request.
		if ( isset( $_GET[ self::PROBE_ARG ] ) ) {
			return;
		}
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Only compared, never printed.
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		if ( self::llms_path() !== $path ) {
			return;
		}
		$state = self::state();
		if ( empty( $state['published'] ) || '' === trim( $state['content'] ) ) {
			return;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo rtrim( self::current_sitemap_link( $state['content'] ) ) . "\n\n" . self::SIGNATURE . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text file, saved through sanitize_textarea_field().
		exit;
	}

	/**
	 * Keep the sitemap line that Lift added ("- [Sitemap](...)") pointing at the sitemap that works today,
	 * for example after switching from Yoast to another SEO plugin (found in testing, 9.11.2026).
	 * Nothing else in the owner's text is touched.
	 *
	 * @param string $content llms.txt text.
	 * @return string
	 */
	public static function current_sitemap_link( $content ) {
		$now = Robots::sitemap_url();
		if ( '' === $now ) {
			return $content;
		}
		return preg_replace( '/^(- \[Sitemap\]\()[^)\s]+(\))[ \t]*$/m', '${1}' . str_replace( array( '\\', '$' ), array( '\\\\', '\$' ), $now ) . '${2}', $content );
	}

	/**
	 * Does something other than Lift already provide llms.txt?
	 *
	 * @return array|null { source: string, body: string } or null when nothing else does.
	 */
	public static function detect_other() {
		$file = trailingslashit( ABSPATH ) . 'llms.txt';
		if ( function_exists( 'get_home_path' ) ) {
			$file = trailingslashit( get_home_path() ) . 'llms.txt';
		}

		$yoast_on = false;
		$wpseo    = get_option( 'wpseo', array() );
		if ( is_array( $wpseo ) && ! empty( $wpseo['enable_llms_txt'] ) ) {
			$yoast_on = true;
		}

		if ( file_exists( $file ) ) {
			$body = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file.
			return array(
				'source' => $yoast_on ? 'Yoast SEO' : __( 'A file in your site folder', 'zarmumia-lift' ),
				'body'   => $body,
			);
		}
		if ( $yoast_on ) {
			return array(
				'source' => 'Yoast SEO',
				'body'   => '',
			);
		}

		// Ask the site itself, with Lift switched off for this one request. Some servers cannot call
		// themselves and just time out, so the answer is remembered for a while.
		$cached = get_transient( self::PROBE_CACHE );
		if ( is_array( $cached ) ) {
			return $cached['found'] ? $cached['found'] : null;
		}
		$response = wp_remote_get(
			add_query_arg( self::PROBE_ARG, '1', home_url( '/llms.txt' ) ),
			array(
				'timeout'     => 2,
				'redirection' => 0,
				'sslverify'   => false, // Loopback to the same site.
			)
		);
		$type = is_wp_error( $response ) ? '' : (string) wp_remote_retrieve_header( $response, 'content-type' );
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response )
			|| ( false === strpos( $type, 'text/plain' ) && false === strpos( $type, 'text/markdown' ) ) ) {
			set_transient( self::PROBE_CACHE, array( 'found' => false ), 12 * HOUR_IN_SECONDS );
			return null;
		}

		$known  = array(
			'all-in-one-seo-pack/all_in_one_seo_pack.php'         => 'All in One SEO',
			'all-in-one-seo-pack-pro/all_in_one_seo_pack.php'     => 'All in One SEO',
			'seo-by-rank-math/rank-math.php'                      => 'Rank Math',
			'website-llms-txt/website-llms-txt.php'               => 'Website LLMs.txt',
		);
		$source = __( 'Another plugin', 'zarmumia-lift' );
		foreach ( $known as $plugin => $label ) {
			if ( in_array( $plugin, (array) get_option( 'active_plugins', array() ), true ) ) {
				$source = $label;
				break;
			}
		}
		$found = array(
			'source' => $source,
			'body'   => (string) wp_remote_retrieve_body( $response ),
		);
		set_transient( self::PROBE_CACHE, array( 'found' => $found ), 12 * HOUR_IN_SECONDS );
		return $found;
	}

	/**
	 * Build a draft from the business details and the chosen pages, in the site's language.
	 *
	 * @return string
	 */
	public static function generate() {
		$switched = switch_to_locale( get_locale() );
		$b        = Business::get();
		$lines    = array();

		$lines[] = '# ' . self::clean_line( $b['name'] );
		$lines[] = '';
		if ( '' !== trim( $b['description'] ) ) {
			$lines[] = '> ' . self::clean_line( $b['description'] );
			$lines[] = '';
		}

		$facts = array();
		if ( $b['founder_name'] ) {
			$facts[] = __( 'Founder', 'zarmumia-lift' ) . ': ' . self::clean_line( $b['founder_name'] . ( $b['founder_role'] ? ', ' . $b['founder_role'] : '' ) );
		}
		if ( $b['city'] ) {
			$facts[] = __( 'City', 'zarmumia-lift' ) . ': ' . self::clean_line( $b['city'] );
		}
		if ( $b['area'] ) {
			$facts[] = __( 'Service area', 'zarmumia-lift' ) . ': ' . self::clean_line( $b['area'] );
		}
		$langs = array_intersect_key( Business::language_choices(), array_flip( $b['languages'] ) );
		if ( $langs ) {
			$facts[] = __( 'Languages', 'zarmumia-lift' ) . ': ' . implode( ', ', $langs );
		}
		$contact = array_filter( array( $b['phone'], $b['email'] ) );
		if ( $contact ) {
			$facts[] = __( 'Contact', 'zarmumia-lift' ) . ': ' . implode( ' · ', $contact );
		}
		if ( $facts ) {
			$lines   = array_merge( $lines, $facts );
			$lines[] = '';
		}

		$page_lines = array();
		foreach ( $b['pages'] as $id ) {
			if ( 'publish' === get_post_status( $id ) ) {
				$page_lines[] = self::page_line( $id );
			}
		}
		if ( $page_lines ) {
			$lines[] = '## ' . __( 'Important pages', 'zarmumia-lift' );
			$lines[] = '';
			$lines   = array_merge( $lines, $page_lines );
			$lines[] = '';
		}

		$link_lines = array();
		foreach ( Business::link_choices() as $key => $label ) {
			if ( ! empty( $b['links'][ $key ] ) ) {
				$link_lines[] = '- ' . $label . ': ' . $b['links'][ $key ];
			}
		}
		if ( $link_lines ) {
			$lines[] = '## ' . __( 'Elsewhere', 'zarmumia-lift' );
			$lines[] = '';
			$lines   = array_merge( $lines, $link_lines );
			$lines[] = '';
		}

		if ( $switched ) {
			restore_previous_locale();
		}
		return trim( implode( "\n", $lines ) ) . "\n";
	}

	/**
	 * One list line for a page: "- [Title](link): summary".
	 *
	 * @param int $id Page ID.
	 * @return string
	 */
	private static function page_line( $id ) {
		$title   = str_replace( array( '[', ']' ), array( '(', ')' ), self::clean_line( get_the_title( $id ) ) );
		$summary = self::page_summary( $id );
		return '- [' . $title . '](' . get_permalink( $id ) . ')' . ( $summary ? ': ' . $summary : '' );
	}

	/**
	 * IDs of all published pages.
	 *
	 * @return int[]
	 */
	public static function published_page_ids() {
		return array_map(
			'intval',
			get_posts(
				array(
					'post_type'      => 'page',
					'post_status'    => 'publish',
					'fields'         => 'ids',
					'posts_per_page' => 500,
					'no_found_rows'  => true,
				)
			)
		);
	}

	/**
	 * Pages published since llms.txt was last published or rebuilt (only while it is published).
	 *
	 * @return int[]
	 */
	public static function new_pages() {
		$state = self::state();
		if ( empty( $state['published'] ) || ! isset( $state['seen_pages'] ) ) {
			return array();
		}
		return array_values( array_diff( self::published_page_ids(), array_map( 'intval', (array) $state['seen_pages'] ) ) );
	}

	/**
	 * Add list lines for new pages to the text, under the "Important pages" heading when it exists.
	 *
	 * @param string $content Current text.
	 * @param int[]  $ids     Page IDs to add.
	 * @return string
	 */
	private static function add_pages_to_content( $content, array $ids ) {
		$switched = switch_to_locale( get_locale() );
		$heading  = '## ' . __( 'Important pages', 'zarmumia-lift' );
		if ( $switched ) {
			restore_previous_locale();
		}

		$new_lines = array_map( array( __CLASS__, 'page_line' ), $ids );
		$lines     = explode( "\n", rtrim( str_replace( "\r\n", "\n", $content ) ) );
		$start     = array_search( $heading, array_map( 'trim', $lines ), true );

		if ( false === $start ) {
			return rtrim( $content ) . "\n\n" . $heading . "\n\n" . implode( "\n", $new_lines ) . "\n";
		}

		// Insert after the last list line that follows the heading.
		$insert_at = $start + 1;
		for ( $i = $start + 1, $n = count( $lines ); $i < $n; $i++ ) {
			$line = trim( $lines[ $i ] );
			if ( 0 === strpos( $line, '## ' ) ) {
				break;
			}
			if ( 0 === strpos( $line, '- ' ) ) {
				$insert_at = $i + 1;
			}
		}
		array_splice( $lines, $insert_at, 0, $new_lines );
		return implode( "\n", $lines ) . "\n";
	}

	/**
	 * Admin notice on the dashboard, the Pages list and Lift's overview when new pages are waiting.
	 */
	public static function new_pages_notice() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'edit-page', 'toplevel_page_' . Admin::MENU_SLUG ), true ) ) {
			return;
		}
		$count = count( self::new_pages() );
		if ( ! $count ) {
			return;
		}
		?>
		<div class="notice notice-info">
			<p>
				<?php
				/* translators: %s: number of new pages. */
				echo esc_html( sprintf( _n( 'Lift: %s new page was added to your site since your llms.txt was published.', 'Lift: %s new pages were added to your site since your llms.txt was published.', $count, 'zarmumia-lift' ), number_format_i18n( $count ) ) );
				?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ); ?>"><?php esc_html_e( 'Update llms.txt?', 'zarmumia-lift' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * One line of plain text: no tags, no line breaks.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private static function clean_line( $text ) {
		return trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $text ) ) );
	}

	/**
	 * Short summary of a page: the SEO plugin's description if set, else the excerpt, else the first words.
	 *
	 * @param int $id Page ID.
	 * @return string
	 */
	private static function page_summary( $id ) {
		foreach ( array( '_yoast_wpseo_metadesc', 'rank_math_description', '_aioseo_description' ) as $key ) {
			$value = (string) get_post_meta( $id, $key, true );
			if ( '' !== $value && false === strpos( $value, '%%' ) && false === strpos( $value, '#' ) ) {
				return self::clean_line( $value );
			}
		}
		$post = get_post( $id );
		if ( ! $post ) {
			return '';
		}
		if ( has_excerpt( $post ) ) {
			return self::clean_line( $post->post_excerpt );
		}
		// Keep a space between paragraphs, headings and list items, so words do not stick together.
		$html = preg_replace( '#</(p|h[1-6]|li|div|figure|figcaption|a|button|td|th)>#i', '$0 ', strip_shortcodes( $post->post_content ) );
		$text = self::clean_line( $html );
		return wp_trim_words( $text, 25, '…' );
	}

	/**
	 * Save / publish / unpublish / rebuild.
	 */
	public static function handle_action() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}
		check_admin_referer( self::ACTION );
		delete_transient( self::PROBE_CACHE ); // Check again for another llms.txt after any action.

		$do    = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$state = self::state();

		if ( in_array( $do, array( 'save', 'publish' ), true ) && isset( $_POST['content'] ) ) {
			$content          = sanitize_textarea_field( wp_unslash( $_POST['content'] ) );
			$state['content'] = function_exists( 'mb_strcut' ) ? mb_strcut( $content, 0, self::MAX_BYTES, 'UTF-8' ) : substr( $content, 0, self::MAX_BYTES );
		}

		$notice = 'saved';
		switch ( $do ) {
			case 'publish':
				if ( self::detect_other() ) {
					$notice = 'blocked';
					break;
				}
				$state['published'] = '' !== trim( $state['content'] );
				$notice             = $state['published'] ? 'published' : 'empty';
				if ( $state['published'] ) {
					$state['seen_pages'] = self::published_page_ids();
				}
				break;
			case 'unpublish':
				$state['published'] = false;
				$notice             = 'unpublished';
				break;
			case 'rebuild':
				$state['content']    = self::generate();
				$state['seen_pages'] = self::published_page_ids();
				$notice              = 'rebuilt';
				break;
			case 'skip_pages':
				$state['seen_pages'] = self::published_page_ids();
				$notice              = 'pages_skipped';
				break;
			case 'add_pages':
				$chosen = isset( $_POST['new_pages'] ) && is_array( $_POST['new_pages'] ) ? array_map( 'absint', wp_unslash( $_POST['new_pages'] ) ) : array();
				$chosen = array_values( array_intersect( self::new_pages(), $chosen ) );
				if ( $chosen ) {
					$state['content'] = self::add_pages_to_content( $state['content'], $chosen );
					$business         = Business::get();
					$business['pages'] = array_values( array_unique( array_merge( array_map( 'intval', $business['pages'] ), $chosen ) ) );
					update_option( Business::OPTION, $business, false );
				}
				$state['seen_pages'] = self::published_page_ids();
				$notice              = $chosen ? 'pages_added' : 'pages_skipped';
				break;
		}

		$state['updated'] = time();
		update_option( self::OPTION, $state, false );

		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE_SLUG, 'notice' => $notice ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * The llms.txt screen.
	 */
	public static function render() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}
		$state = self::state();
		$other = self::detect_other();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flag after redirect.
		$notice = isset( $_GET['notice'] ) ? sanitize_key( wp_unslash( $_GET['notice'] ) ) : '';

		$messages = array(
			'saved'       => array( 'success', __( 'Draft saved. It is not on your site yet.', 'zarmumia-lift' ) ),
			'published'   => array( 'success', __( 'Published. Your llms.txt is now on your site.', 'zarmumia-lift' ) ),
			'unpublished' => array( 'success', __( 'Removed from your site. The draft is kept.', 'zarmumia-lift' ) ),
			'rebuilt'     => array( 'success', __( 'A new draft was built from your business details. Check it, then save or publish.', 'zarmumia-lift' ) ),
			'empty'       => array( 'warning', __( 'The text is empty, so nothing was published.', 'zarmumia-lift' ) ),
			'blocked'     => array( 'warning', __( 'Your site already has an llms.txt, so Lift did not publish a second one.', 'zarmumia-lift' ) ),
			'pages_added' => array( 'success', __( 'The new pages were added and your llms.txt on the site was updated.', 'zarmumia-lift' ) ),
			'pages_skipped' => array( 'success', __( 'OK, your llms.txt stays as it is.', 'zarmumia-lift' ) ),
		);
		$new_pages = self::new_pages();

		$content = '' !== $state['content'] ? self::current_sitemap_link( $state['content'] ) : ( Business::is_complete() ? self::generate() : '' );
		?>
		<div class="wrap zarmumia-lift">
			<h1><?php esc_html_e( 'llms.txt', 'zarmumia-lift' ); ?></h1>

			<?php if ( isset( $messages[ $notice ] ) ) : ?>
				<div class="notice notice-<?php echo esc_attr( $messages[ $notice ][0] ); ?> is-dismissible"><p><?php echo esc_html( $messages[ $notice ][1] ); ?></p></div>
			<?php endif; ?>

			<div class="zarmumia-lift-card">
				<p><?php esc_html_e( 'llms.txt is a short summary of your business and your important pages, written for AI engines. It is a new, optional standard: today most crawlers rarely ask for it, but it is quick and does no harm.', 'zarmumia-lift' ); ?></p>

				<?php if ( $other ) : ?>
					<div class="zarmumia-lift-status zarmumia-lift-status--info">
						<strong><?php esc_html_e( 'Your site already has an llms.txt.', 'zarmumia-lift' ); ?></strong>
						<?php
						/* translators: %s: where the existing llms.txt comes from, e.g. Yoast SEO. */
						echo esc_html( sprintf( __( 'It comes from: %s. Lift will not create a second one.', 'zarmumia-lift' ), $other['source'] ) );
						?>
						<br /><?php esc_html_e( 'If you prefer Lift\'s version below, turn off llms.txt in that plugin first, then come back here and publish.', 'zarmumia-lift' ); ?>
					</div>
					<?php if ( '' !== $other['body'] ) : ?>
						<h3><?php esc_html_e( 'What is there now', 'zarmumia-lift' ); ?></h3>
						<textarea class="large-text code" rows="8" readonly><?php echo esc_textarea( $other['body'] ); ?></textarea>
					<?php endif; ?>
				<?php elseif ( $state['published'] ) : ?>
					<div class="zarmumia-lift-status zarmumia-lift-status--ok">
						<strong><?php esc_html_e( 'Published.', 'zarmumia-lift' ); ?></strong>
						<a href="<?php echo esc_url( home_url( '/llms.txt' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View it on your site', 'zarmumia-lift' ); ?></a>
					</div>
					<?php if ( $new_pages ) : ?>
						<form class="zarmumia-lift-status zarmumia-lift-status--info" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
							<?php wp_nonce_field( self::ACTION ); ?>
							<p class="zarmumia-lift-new-pages"><strong><?php esc_html_e( 'New pages were added to your site.', 'zarmumia-lift' ); ?></strong> <?php esc_html_e( 'Choose which ones to add to your llms.txt. Your own edits to the text are kept.', 'zarmumia-lift' ); ?></p>
							<?php foreach ( $new_pages as $page_id ) : ?>
								<label class="zarmumia-lift-check zarmumia-lift-check--block">
									<input type="checkbox" name="new_pages[]" value="<?php echo esc_attr( $page_id ); ?>" checked />
									<?php echo esc_html( get_the_title( $page_id ) ); ?>
								</label>
							<?php endforeach; ?>
							<div class="zarmumia-lift-actions">
								<button type="submit" class="button button-primary" name="do" value="add_pages"><?php esc_html_e( 'Add and update on site', 'zarmumia-lift' ); ?></button>
								<button type="submit" class="button" name="do" value="skip_pages" formnovalidate><?php esc_html_e( 'Not now', 'zarmumia-lift' ); ?></button>
							</div>
						</form>
					<?php endif; ?>
				<?php else : ?>
					<div class="zarmumia-lift-status">
						<strong><?php esc_html_e( 'Not published yet.', 'zarmumia-lift' ); ?></strong>
						<?php esc_html_e( 'Read the draft, change anything you like, then publish.', 'zarmumia-lift' ); ?>
					</div>
				<?php endif; ?>

				<?php if ( ! Business::is_complete() && '' === $state['content'] ) : ?>
					<p><?php esc_html_e( 'First answer the short questions about your business. Lift builds the draft from your answers.', 'zarmumia-lift' ); ?></p>
					<p><a class="button button-primary" href="<?php echo esc_url( Wizard::url( 'business' ) ); ?>"><?php esc_html_e( 'Start', 'zarmumia-lift' ); ?></a></p>
				<?php else : ?>
					<h3><?php echo $other ? esc_html__( 'Lift\'s version', 'zarmumia-lift' ) : esc_html__( 'Your llms.txt', 'zarmumia-lift' ); ?></h3>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
						<?php wp_nonce_field( self::ACTION ); ?>
						<textarea class="large-text code zarmumia-lift-llms-text" rows="18" name="content" dir="auto"><?php echo esc_textarea( $content ); ?></textarea>
						<div class="zarmumia-lift-actions">
							<?php if ( ! $other ) : ?>
								<button type="submit" class="button button-primary" name="do" value="publish"><?php echo $state['published'] ? esc_html__( 'Save and update on site', 'zarmumia-lift' ) : esc_html__( 'Publish', 'zarmumia-lift' ); ?></button>
							<?php endif; ?>
							<button type="submit" class="button" name="do" value="save"><?php esc_html_e( 'Save draft', 'zarmumia-lift' ); ?></button>
							<button type="submit" class="button" name="do" value="rebuild"><?php esc_html_e( 'Rebuild from business details', 'zarmumia-lift' ); ?></button>
							<?php if ( $state['published'] ) : ?>
								<button type="submit" class="button button-link-delete" name="do" value="unpublish"><?php esc_html_e( 'Remove from site', 'zarmumia-lift' ); ?></button>
							<?php endif; ?>
						</div>
					</form>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
