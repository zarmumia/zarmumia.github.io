<?php
/**
 * Runs only when the plugin is deleted from the Plugins screen.
 * Removes everything Lift stored, so the site returns exactly to how it was.
 *
 * @package ZarmumiaLift
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Settings ("zarmumia_lift_...") and temporary cached values ("_transient_zarmumia_lift_...", "_transient_timeout_zarmumia_lift_...").
$zarmumia_lift_patterns = array(
	$wpdb->esc_like( 'zarmumia_lift_' ) . '%',
	$wpdb->esc_like( '_transient_zarmumia_lift_' ) . '%',
	$wpdb->esc_like( '_transient_timeout_zarmumia_lift_' ) . '%',
	$wpdb->esc_like( '_site_transient_zarmumia_lift_' ) . '%',
	$wpdb->esc_like( '_site_transient_timeout_zarmumia_lift_' ) . '%',
);

// Page fixes: Lift's own data on pages ("_zarmumia_lift_..."): last check, image descriptions, own description.
// A description saved in Yoast's or Rank Math's own field belongs to that plugin and stays (decided 9.11.2026).
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s", $wpdb->esc_like( '_zarmumia_lift_' ) . '%' ) );
wp_cache_flush();

foreach ( $zarmumia_lift_patterns as $zarmumia_lift_like ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$zarmumia_lift_options = $wpdb->get_col(
		$wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $zarmumia_lift_like )
	);
	foreach ( $zarmumia_lift_options as $zarmumia_lift_option ) {
		delete_option( $zarmumia_lift_option );
	}
}
