/* Lift readiness check: fetch a page as a logged-out visitor, send it to the site for analysis. */
( function () {
	var cfg = window.zarmumiaLiftScan;
	if ( ! cfg ) {
		return;
	}

	// Fetch one page and have the site check it. quiet = only save (for "Check all pages").
	// A page that never answers must not block "Check all pages": give up on it after 20 seconds.
	function withTimeout( promise, ms ) {
		return Promise.race( [
			promise,
			new Promise( function ( resolve, reject ) {
				setTimeout( function () { reject( new Error( 'timeout' ) ); }, ms );
			} )
		] );
	}

	function check( url, pageId, quiet ) {
		return withTimeout( fetch( url, { credentials: 'omit', cache: 'no-store' } ), 20000 )
			.then( function ( r ) { return r.text(); } )
			.then( function ( html ) {
				var body = new FormData();
				body.append( 'action', cfg.action );
				body.append( 'nonce', cfg.nonce );
				body.append( 'page_id', pageId || 0 );
				body.append( 'html', html );
				if ( quiet ) {
					body.append( 'quiet', '1' );
				}
				return fetch( cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } );
			} )
			.then( function ( r ) { return r.json(); } )
			.then( function ( res ) {
				if ( ! res || ! res.success ) {
					throw new Error( 'scan failed' );
				}
				return res.data;
			} );
	}

	// This page.
	var box = document.getElementById( 'zarmumia-lift-results' );
	var btn = document.getElementById( 'zarmumia-lift-rescan' );
	var status = document.getElementById( 'zarmumia-lift-scan-status' );
	if ( box && btn ) {
		var run = function () {
			btn.disabled = true;
			status.textContent = '…';
			check( cfg.url, cfg.pageId, false )
				.then( function ( data ) {
					box.innerHTML = data.html;
					status.textContent = '';
					if ( window.location.hash ) {
						var target = document.getElementById( window.location.hash.slice( 1 ) );
						if ( target ) {
							target.scrollIntoView();
						}
					}
				} )
				.catch( function () {
					status.textContent = cfg.failed;
				} )
				.finally( function () {
					btn.disabled = false;
				} );
		};
		btn.addEventListener( 'click', run );
		if ( '1' === box.getAttribute( 'data-auto' ) ) {
			run();
		}
	}

	// Whole site: every page, one after the other, then show the table again.
	var all = document.getElementById( 'zarmumia-lift-check-all' );
	var allStatus = document.getElementById( 'zarmumia-lift-all-status' );
	if ( all && cfg.pages && cfg.pages.length ) {
		all.addEventListener( 'click', function () {
			var i = 0;
			all.disabled = true;
			var next = function () {
				if ( i >= cfg.pages.length ) {
					window.location.hash = 'zarmumia-lift-all';
					window.location.reload();
					return;
				}
				allStatus.textContent = cfg.progress.replace( '%1$s', i + 1 ).replace( '%2$s', cfg.pages.length );
				var page = cfg.pages[ i++ ];
				check( page.url, page.id, true ).catch( function () {} ).then( next );
			};
			next();
		} );
	}
} )();
