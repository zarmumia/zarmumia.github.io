/* Lift: choose the business logo from the media library (wizard, first step). */
( function ( $ ) {
	var cfg = window.zarmumiaLiftLogo;
	var input = document.getElementById( 'zarmumia-lift-logo' );
	if ( ! cfg || ! input || ! window.wp || ! wp.media ) {
		return;
	}
	var preview = document.getElementById( 'zarmumia-lift-logo-preview' );
	var none = document.getElementById( 'zarmumia-lift-logo-none' );
	var remove = document.getElementById( 'zarmumia-lift-logo-remove' );
	var frame;

	function show( url ) {
		preview.src = url || '';
		preview.hidden = ! url;
		none.hidden = !! url;
	}

	document.getElementById( 'zarmumia-lift-logo-choose' ).addEventListener( 'click', function () {
		if ( ! frame ) {
			frame = wp.media( {
				title: cfg.title,
				button: { text: cfg.button },
				library: { type: 'image' },
				multiple: false
			} );
			frame.on( 'select', function () {
				var image = frame.state().get( 'selection' ).first().toJSON();
				var size = image.sizes && image.sizes.medium ? image.sizes.medium : image;
				input.value = image.id;
				show( size.url );
				remove.hidden = false;
			} );
		}
		frame.open();
	} );

	remove.addEventListener( 'click', function () {
		input.value = '0';
		show( input.getAttribute( 'data-site' ) ); // Back to the site's own logo, if there is one.
		remove.hidden = true;
	} );
} )( jQuery );
