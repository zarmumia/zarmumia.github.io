<?php
/**
 * Business details: storage, defaults (pre-filled from the site) and input cleaning.
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads and writes the business details answered in the setup wizard.
 */
class Business {

	const OPTION = 'zarmumia_lift_business';

	/**
	 * Languages offered in the wizard (code => label in English, translated in the UI).
	 *
	 * @return array
	 */
	public static function language_choices() {
		return array(
			'he' => __( 'Hebrew', 'zarmumia-lift' ),
			'en' => __( 'English', 'zarmumia-lift' ),
			'ar' => __( 'Arabic', 'zarmumia-lift' ),
			'ru' => __( 'Russian', 'zarmumia-lift' ),
			'fr' => __( 'French', 'zarmumia-lift' ),
		);
	}

	/**
	 * Link fields offered in the wizard (key => label).
	 *
	 * @return array
	 */
	public static function link_choices() {
		return array(
			'google_business' => __( 'Google Business Profile', 'zarmumia-lift' ),
			'facebook'        => __( 'Facebook', 'zarmumia-lift' ),
			'instagram'       => __( 'Instagram', 'zarmumia-lift' ),
			'linkedin'        => __( 'LinkedIn', 'zarmumia-lift' ),
			'youtube'         => __( 'YouTube', 'zarmumia-lift' ),
			'tiktok'          => __( 'TikTok', 'zarmumia-lift' ),
		);
	}

	/**
	 * Saved details, or sensible defaults taken from the site when nothing is saved yet.
	 *
	 * @return array
	 */
	public static function get() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	/**
	 * Whether the wizard has been completed at least once.
	 *
	 * @return bool
	 */
	public static function is_complete() {
		$saved = get_option( self::OPTION, array() );
		return is_array( $saved ) && ! empty( $saved['completed'] );
	}

	/**
	 * Defaults pre-filled from WordPress settings (and from Yoast, if it is installed). Read only.
	 *
	 * @return array
	 */
	public static function defaults() {
		$locale_lang = substr( get_locale(), 0, 2 );
		$languages   = array_key_exists( $locale_lang, self::language_choices() ) ? array( $locale_lang ) : array();

		$links = array_fill_keys( array_keys( self::link_choices() ), '' );
		$name  = get_bloginfo( 'name' );

		// Yoast stores social profiles and the organisation name; reuse them so she does not type twice.
		$yoast_social = get_option( 'wpseo_social', array() );
		if ( is_array( $yoast_social ) ) {
			if ( ! empty( $yoast_social['facebook_site'] ) ) {
				$links['facebook'] = $yoast_social['facebook_site'];
			}
			if ( ! empty( $yoast_social['other_social_urls'] ) && is_array( $yoast_social['other_social_urls'] ) ) {
				foreach ( $yoast_social['other_social_urls'] as $url ) {
					$key = self::guess_link_key( $url );
					if ( $key && '' === $links[ $key ] ) {
						$links[ $key ] = $url;
					}
				}
			}
		}
		$yoast_titles = get_option( 'wpseo_titles', array() );
		if ( is_array( $yoast_titles ) && ! empty( $yoast_titles['company_name'] ) ) {
			$name = $yoast_titles['company_name'];
		}

		$front = (int) get_option( 'page_on_front' );

		return array(
			'name'         => $name,
			'description'  => get_bloginfo( 'description' ),
			'founder_name' => '',
			'founder_role' => '',
			'area'         => '',
			'city'         => '',
			'languages'    => $languages,
			'phone'        => '',
			'email'        => '',
			'links'        => $links,
			'logo'         => 0, // Image from the media library, chosen in Lift. 0 = use the site's own logo.
			'pages'        => $front ? array( $front ) : array(),
			'completed'    => false,
		);
	}

	/**
	 * Which link field a URL most likely belongs to.
	 *
	 * @param string $url URL.
	 * @return string Empty when unknown.
	 */
	private static function guess_link_key( $url ) {
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		$map  = array(
			'instagram.com' => 'instagram',
			'linkedin.com'  => 'linkedin',
			'youtube.com'   => 'youtube',
			'tiktok.com'    => 'tiktok',
			'facebook.com'  => 'facebook',
		);
		foreach ( $map as $domain => $key ) {
			if ( false !== strpos( $host, $domain ) ) {
				return $key;
			}
		}
		return '';
	}

	/**
	 * Clean the fields of one wizard step and merge them into the saved details.
	 *
	 * @param string $step  Step key.
	 * @param array  $input Raw $_POST data (already unslashed).
	 */
	public static function save_step( $step, array $input ) {
		$data = self::get();

		switch ( $step ) {
			case 'business':
				$data['name']        = sanitize_text_field( $input['name'] ?? '' );
				$data['description'] = sanitize_textarea_field( $input['description'] ?? '' );
				$logo                = absint( $input['logo'] ?? 0 );
				$data['logo']        = $logo && wp_attachment_is_image( $logo ) ? $logo : 0;
				break;

			case 'people':
				$data['founder_name'] = sanitize_text_field( $input['founder_name'] ?? '' );
				$data['founder_role'] = sanitize_text_field( $input['founder_role'] ?? '' );
				$data['area']         = sanitize_text_field( $input['area'] ?? '' );
				$data['city']         = sanitize_text_field( $input['city'] ?? '' );
				$data['phone']        = preg_replace( '/[^0-9+\-\s()]/', '', (string) ( $input['phone'] ?? '' ) );
				$data['email']        = sanitize_email( $input['email'] ?? '' );
				$langs                = isset( $input['languages'] ) && is_array( $input['languages'] ) ? $input['languages'] : array();
				$data['languages']    = array_values( array_intersect( array_keys( self::language_choices() ), array_map( 'sanitize_key', $langs ) ) );
				break;

			case 'links':
				$links = isset( $input['links'] ) && is_array( $input['links'] ) ? $input['links'] : array();
				foreach ( array_keys( self::link_choices() ) as $key ) {
					$url                   = isset( $links[ $key ] ) ? trim( (string) $links[ $key ] ) : '';
					$data['links'][ $key ] = '' === $url ? '' : esc_url_raw( $url, array( 'http', 'https' ) );
				}
				break;

			case 'pages':
				$ids = isset( $input['pages'] ) && is_array( $input['pages'] ) ? array_map( 'absint', $input['pages'] ) : array();
				$ok  = array();
				foreach ( $ids as $id ) {
					if ( $id && 'publish' === get_post_status( $id ) ) {
						$ok[] = $id;
					}
				}
				$data['pages']     = array_values( array_unique( $ok ) );
				$data['completed'] = true;
				break;
		}

		update_option( self::OPTION, $data, false );
	}
}
