<?php
/**
 * AI readiness score: checks the home page the way a visitor (and a crawler) gets it.
 *
 * The owner's browser fetches the home page (as a logged-out visitor) and sends the HTML here for analysis,
 * because many servers cannot request their own pages. Nothing leaves the site. Nothing is changed: this is a report.
 *
 * Weights follow the market check: most points for being reachable by Google and AI search, then correct business
 * details, then clear content. llms.txt counts little.
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Readiness feature.
 */
class Readiness {

	const OPTION    = 'zarmumia_lift_scan';
	const AJAX      = 'zarmumia_lift_scan';
	const PAGE_SLUG = 'zarmumia-lift-readiness';
	const MAX_HTML  = 3000000;

	/**
	 * Where lazy-loaded images keep their real address (the "src" is only a placeholder).
	 */
	const LAZY_ATTRS = array( 'data-lazyload', 'data-src', 'data-lazy-src', 'data-original' );

	/**
	 * Checks whose fix lives in the full version. In the free version they show "In the full version".
	 */
	const PRO_FIXES = array( 'ai_search', 'schema', 'sitemap', 'faq' );

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		add_action( 'wp_ajax_' . self::AJAX, array( __CLASS__, 'ajax_scan' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	/**
	 * Script that fetches the home page and sends it for analysis (only on this screen).
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public static function enqueue( $hook_suffix ) {
		if ( false === strpos( (string) $hook_suffix, self::PAGE_SLUG ) ) {
			return;
		}
		$id  = self::target();
		$cfg = array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'action'  => self::AJAX,
			'nonce'   => wp_create_nonce( self::AJAX ),
			'url'     => self::url( $id ),
			'pageId'  => $id,
			'failed'  => self::is_home( $id )
				? __( 'The check could not read your home page. Try again in a moment.', 'zarmumia-lift' )
				: __( 'The check could not read this page. Try again in a moment.', 'zarmumia-lift' ),
		);
		if ( ZARMUMIA_LIFT_SITE ) {
			$cfg = array_merge( $cfg, Site_Pages::script_data() );
		}
		wp_enqueue_script( 'zarmumia-lift-scan', ZARMUMIA_LIFT_URL . 'assets/scan.js', array(), ZARMUMIA_LIFT_VERSION, true );
		wp_localize_script( 'zarmumia-lift-scan', 'zarmumiaLiftScan', $cfg );
	}

	/**
	 * The page the main score checks: the home page (free, whole site) or the chosen page (landing page package).
	 *
	 * @return int 0 = the home page when it is not a page.
	 */
	public static function main_id() {
		return ZARMUMIA_LIFT_PRO ? Page_Fixes::main_id() : 0;
	}

	/**
	 * The page this screen shows: the main page, or (whole site) the page asked for.
	 *
	 * @return int
	 */
	public static function target() {
		$id = self::main_id();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation.
		$asked = isset( $_GET['page_id'] ) ? absint( $_GET['page_id'] ) : 0;
		if ( ZARMUMIA_LIFT_SITE && $asked && Page_Fixes::allowed( $asked ) ) {
			$id = $asked;
		}
		return $id;
	}

	/**
	 * Address of a page (0 = home).
	 *
	 * @param int $id Page ID.
	 * @return string
	 */
	public static function url( $id ) {
		return $id ? (string) get_permalink( $id ) : home_url( '/' );
	}

	/**
	 * Is this the home page?
	 *
	 * @param int $id Page ID.
	 * @return bool
	 */
	public static function is_home( $id ) {
		return ! $id || ( 'page' === get_option( 'show_on_front' ) && (int) get_option( 'page_on_front' ) === (int) $id );
	}

	/**
	 * Saved check of a page.
	 *
	 * @param int $id Page ID.
	 * @return array|null
	 */
	public static function saved( $id ) {
		if ( $id === self::main_id() ) {
			$scan = get_option( self::OPTION );
			return is_array( $scan ) ? $scan : null;
		}
		return ZARMUMIA_LIFT_PRO ? Page_Fixes::saved_scan( $id ) : null;
	}

	/**
	 * Receive a page's HTML, analyse it, save and return the result.
	 */
	public static function ajax_scan() {
		check_ajax_referer( self::AJAX, 'nonce' );
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_send_json_error( null, 403 );
		}
		$id = ZARMUMIA_LIFT_PRO && isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
		if ( $id && ! Page_Fixes::allowed( $id ) ) {
			wp_send_json_error( null, 403 );
		}
		// Raw HTML is only parsed for the checks below; it is never printed or stored.
		$html = isset( $_POST['html'] ) ? substr( (string) wp_unslash( $_POST['html'] ), 0, self::MAX_HTML ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$scan = self::scan( $html, $id );
		if ( $id === self::main_id() ) {
			update_option( self::OPTION, $scan, false );
		}
		if ( $id ) {
			update_post_meta( $id, Page_Fixes::META_SCAN, $scan );
		}
		if ( ! empty( $_POST['quiet'] ) ) {
			wp_send_json_success( array( 'score' => $scan['score'] ) );
		}
		ob_start();
		self::render_results( $scan );
		wp_send_json_success( array( 'html' => ob_get_clean() ) );
	}

	/**
	 * Run every check.
	 *
	 * @param string $html Page HTML.
	 * @param int    $id   Page ID (0 = home).
	 * @return array { time, score, page, imgs, checks: [ id => [ status, data ] ] }
	 */
	public static function scan( $html, $id = 0 ) {
		$page = self::parse_html( $html );
		$c    = array();

		// Access.
		$c['indexing'] = array( '0' !== (string) get_option( 'blog_public' ) ? 'pass' : 'fail', array() );
		$c['noindex']  = array( $page['noindex'] ? 'fail' : 'pass', array() );
		$canonical_ok  = '' === $page['canonical'] || untrailingslashit( $page['canonical'] ) === untrailingslashit( self::url( $id ) );
		$c['canonical'] = array( $canonical_ok ? 'pass' : 'fail', array( $page['canonical'] ) );
		$status         = Robots::status();
		$c['ai_search'] = array( in_array( false, $status['search'], true ) ? 'fail' : 'pass', array() );
		$c['classic']   = array( in_array( false, $status['classic'], true ) ? 'fail' : 'pass', array() );
		$c['https']     = array( 'https' === wp_parse_url( home_url(), PHP_URL_SCHEME ) ? 'pass' : 'fail', array() );

		// Business details.
		$biz            = $page['business'];
		$c['schema']    = array( $biz ? 'pass' : 'fail', array() );
		$details        = $biz ? count( array_intersect( array( 'founder', 'areaServed', 'knowsLanguage', 'address' ), array_keys( $biz ) ) ) : 0;
		$c['details']   = array( $details >= 3 ? 'pass' : ( $details ? 'warn' : 'fail' ), array( $details ) );
		$b              = Business::get();
		if ( '' === $b['phone'] ) {
			$c['phone'] = array( 'fail', array() );
		} else {
			$digits     = preg_replace( '/\D/', '', $b['phone'] );
			$on_page    = '' !== $digits && false !== strpos( preg_replace( '/\D/', '', $page['text'] ), $digits );
			$c['phone'] = array( $on_page ? 'pass' : 'warn', array() );
		}
		$c['google_profile'] = array( '' !== ( $b['links']['google_business'] ?? '' ) ? 'pass' : 'fail', array() );
		$sitemap             = Robots::sitemap_info();
		$c['sitemap']        = array( $sitemap['url'] ? 'pass' : 'fail', array() );

		// Content.
		$c['title']       = array( '' !== $page['title'] ? 'pass' : 'fail', array() );
		$c['description'] = array( '' !== $page['description'] ? 'pass' : 'fail', array() );
		$c['h1']          = array( 1 === $page['h1'] ? 'pass' : 'fail', array( $page['h1'] ) );
		$c['h2']          = array( $page['h2'] > 0 ? 'pass' : 'fail', array() );
		$c['alt']         = array( 0 === $page['img_no_alt'] ? 'pass' : 'fail', array( $page['img_no_alt'], $page['img'] ) );
		$lang_ok          = '' !== $page['lang'] && 0 === strpos( strtolower( $page['lang'] ), substr( get_locale(), 0, 2 ) );
		$site_rtl         = in_array( substr( get_locale(), 0, 2 ), array( 'he', 'ar', 'fa', 'ur' ), true );
		$dir_ok           = ! $site_rtl || 'rtl' === strtolower( $page['dir'] );
		$c['lang']        = array( $lang_ok && $dir_ok ? 'pass' : 'fail', array() );

		// AI extras.
		$llms         = Llms::state();
		$c['llms']    = array( ! empty( $llms['published'] ) || Llms::detect_other() ? 'pass' : 'fail', array() );
		$c['faq']     = array( $page['faq'] ? 'pass' : 'warn', array() );

		// Report only (no points).
		$c['weight']        = array( $page['bytes'] > 2000000 ? 'warn' : 'pass', array( number_format_i18n( $page['bytes'] / 1000000, 1 ) ) );
		$c['accessibility'] = array( $page['a11y_widget'] ? 'info' : 'pass', array( $page['a11y_widget'] ) );
		$hebrew_slugs       = 0;
		foreach ( $b['pages'] as $important ) {
			if ( preg_match( '/%[89a-f][0-9a-f]/i', (string) get_permalink( $important ) ) ) { // Non-Latin letters in the address (Hebrew, Arabic, Cyrillic...).
				$hebrew_slugs++;
			}
		}
		$c['slugs'] = array( $hebrew_slugs ? 'info' : 'pass', array( $hebrew_slugs ) );

		$earned = 0;
		$total  = 0;
		foreach ( self::weights() as $check => $points ) {
			if ( ! isset( $c[ $check ] ) || 'na' === $c[ $check ][0] ) {
				continue;
			}
			$total  += $points;
			$earned += 'pass' === $c[ $check ][0] ? $points : ( 'warn' === $c[ $check ][0] ? $points / 2 : 0 );
		}

		return array(
			'time'   => time(),
			'score'  => $total ? (int) round( 100 * $earned / $total ) : 0,
			'page'   => (int) $id,
			'imgs'   => $page['img_missing'],
			'checks' => $c,
		);
	}

	/**
	 * Points per check (total 100). Checks not listed are report-only.
	 *
	 * @return array
	 */
	public static function weights() {
		return array(
			'indexing'       => 10,
			'noindex'        => 8,
			'canonical'      => 4,
			'ai_search'      => 8,
			'classic'        => 6,
			'https'          => 4,
			'schema'         => 10,
			'details'        => 5,
			'phone'          => 5,
			'google_profile' => 5,
			'sitemap'        => 5,
			'title'          => 4,
			'description'    => 5,
			'h1'             => 5,
			'h2'             => 3,
			'alt'            => 5,
			'lang'           => 3,
			'llms'           => 3,
			'faq'            => 2,
		);
	}

	/**
	 * Pull what the checks need out of the HTML.
	 *
	 * @param string $html HTML.
	 * @return array
	 */
	private static function parse_html( $html ) {
		$out = array(
			'bytes'       => strlen( $html ),
			'title'       => '',
			'description' => '',
			'canonical'   => '',
			'noindex'     => false,
			'lang'        => '',
			'dir'         => '',
			'h1'          => 0,
			'h2'          => 0,
			'img'         => 0,
			'img_no_alt'  => 0,
			'img_missing' => array(),
			'business'    => array(),
			'faq'         => false,
			'text'        => '',
			'a11y_widget' => '',
		);
		if ( '' === trim( $html ) || ! class_exists( '\DOMDocument' ) ) {
			return $out;
		}

		$doc      = new \DOMDocument();
		$previous = libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );
		$xp = new \DOMXPath( $doc );

		$html_el = $doc->getElementsByTagName( 'html' )->item( 0 );
		if ( $html_el ) {
			$out['lang'] = $html_el->getAttribute( 'lang' );
			$out['dir']  = $html_el->getAttribute( 'dir' );
		}
		$title = $doc->getElementsByTagName( 'title' )->item( 0 );
		$out['title'] = $title ? trim( $title->textContent ) : '';

		foreach ( $xp->query( '//meta[@name]' ) as $meta ) {
			$name = strtolower( $meta->getAttribute( 'name' ) );
			if ( 'description' === $name ) {
				$out['description'] = trim( $meta->getAttribute( 'content' ) );
			}
			if ( in_array( $name, array( 'robots', 'googlebot' ), true ) && preg_match( '/noindex|nosnippet|none/i', $meta->getAttribute( 'content' ) ) ) {
				$out['noindex'] = true;
			}
		}
		$canonical = $xp->query( '//link[@rel="canonical"]' )->item( 0 );
		$out['canonical'] = $canonical ? $canonical->getAttribute( 'href' ) : '';

		// Headings and images inside the page body, not the admin bar.
		$out['h1'] = $xp->query( '//body//h1[not(ancestor::*[@id="wpadminbar"])]' )->length;
		$out['h2'] = $xp->query( '//body//h2[not(ancestor::*[@id="wpadminbar"])]' )->length;
		// Not inside <noscript>: lazy-loading (Elementor, speed plugins) repeats every image there, which would count it twice.
		foreach ( $xp->query( '//body//img[not(ancestor::*[@id="wpadminbar"]) and not(ancestor::noscript)]' ) as $img ) {
			$out['img']++;
			if ( ! $img->hasAttribute( 'alt' ) || ( '' === trim( $img->getAttribute( 'alt' ) ) && 'presentation' !== $img->getAttribute( 'role' ) && 'true' !== $img->getAttribute( 'aria-hidden' ) ) ) {
				$out['img_no_alt']++;
				// Lazy-loaded images carry a placeholder in "src" (data:..., or Slider Revolution's dummy.png) and the
				// real address in a data- attribute (found on real sites, 9.11.2026). The real address wins.
				$src = trim( $img->getAttribute( 'src' ) );
				foreach ( self::LAZY_ATTRS as $lazy ) {
					if ( '' !== trim( $img->getAttribute( $lazy ) ) ) {
						$src = trim( $img->getAttribute( $lazy ) );
						break;
					}
				}
				$src = substr( $src, 0, 2000 );
				if ( '' !== $src && 0 !== strpos( $src, 'data:' ) && ! in_array( $src, $out['img_missing'], true ) && count( $out['img_missing'] ) < 40 ) {
					$out['img_missing'][] = $src; // For the image descriptions fix.
				}
			}
		}

		foreach ( $xp->query( '//script[@type="application/ld+json"]' ) as $script ) {
			$data = json_decode( $script->textContent, true );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$nodes = isset( $data['@graph'] ) ? $data['@graph'] : ( isset( $data[0] ) ? $data : array( $data ) );
			foreach ( $nodes as $node ) {
				$types = (array) ( $node['@type'] ?? array() );
				if ( ! $out['business'] && array_filter( $types, function ( $t ) { return in_array( $t, array( 'Organization', 'LocalBusiness', 'ProfessionalService' ), true ) || 'Business' === substr( (string) $t, -8 ); } ) ) {
					$out['business'] = $node;
				}
				if ( in_array( 'FAQPage', $types, true ) ) {
					$out['faq'] = true;
				}
			}
		}

		$body = $doc->getElementsByTagName( 'body' )->item( 0 );
		$out['text'] = $body ? $body->textContent : '';

		foreach ( array( 'nagishli' => 'Nagish Li', 'accessibe' => 'accessiBe', 'equalweb' => 'EqualWeb', 'userway' => 'UserWay', 'enable.co.il' => 'Enable' ) as $needle => $name ) {
			if ( false !== stripos( $html, $needle ) ) {
				$out['a11y_widget'] = $name;
				break;
			}
		}
		return $out;
	}

	/**
	 * Plain-language text for every check: title, what it means, how to fix, optional link.
	 *
	 * @param string $id   Check id.
	 * @param array  $data Extra data from the scan.
	 * @param bool   $home The checked page is the home page.
	 * @return array { group, title_pass, title_fail, meaning, fix, link }
	 */
	private static function texts( $id, array $data, $home = true ) {
		$lift = function ( $slug ) {
			return admin_url( 'admin.php?page=' . $slug );
		};
		$t = array(
			'indexing'       => array( 'access', __( 'Search engines are allowed to show your site', 'zarmumia-lift' ), __( 'Your site asks search engines not to show it', 'zarmumia-lift' ), __( 'While this is on, Google and AI search will mostly ignore you.', 'zarmumia-lift' ), __( 'Settings → Reading → untick "Discourage search engines". Check with whoever built the site first; sometimes it is on by mistake after building.', 'zarmumia-lift' ), admin_url( 'options-reading.php' ) ),
			'noindex'        => array( 'access', __( 'Your home page can appear in search', 'zarmumia-lift' ), __( 'Your home page is marked "do not show in search"', 'zarmumia-lift' ), __( 'A hidden tag (noindex or nosnippet) tells engines to skip or hide this page.', 'zarmumia-lift' ), __( 'In your SEO plugin, open the home page settings and allow it to appear in search results.', 'zarmumia-lift' ), '' ),
			'canonical'      => array( 'access', __( 'Your home page points to itself as the main version', 'zarmumia-lift' ), __( 'Your home page points to a different address as the main version', 'zarmumia-lift' ), __( 'Engines may show the other address instead of yours.', 'zarmumia-lift' ), __( 'Ask whoever built your site to check the "canonical" setting of the home page.', 'zarmumia-lift' ), '' ),
			'ai_search'      => array( 'access', __( 'AI search crawlers can read your site', 'zarmumia-lift' ), __( 'Some AI search crawlers are blocked', 'zarmumia-lift' ), __( 'Blocked crawlers cannot use your site when answering questions.', 'zarmumia-lift' ), __( 'Open them in Lift, with one click.', 'zarmumia-lift' ), Admin::pro_link( Admin::CRAWLERS_SLUG ) ),
			'classic'        => array( 'access', __( 'Google and Bing can read your site', 'zarmumia-lift' ), __( 'Google or Bing are blocked', 'zarmumia-lift' ), __( 'This hurts your visibility everywhere, including Google\'s AI answers.', 'zarmumia-lift' ), __( 'See the details in Lift, then fix the robots.txt setting in your SEO plugin.', 'zarmumia-lift' ), ( ZARMUMIA_LIFT_PRO ? Admin::pro_link( Admin::CRAWLERS_SLUG ) : '' ) ),
			'https'          => array( 'access', __( 'Your site uses a secure connection (HTTPS)', 'zarmumia-lift' ), __( 'Your site does not use a secure connection (HTTPS)', 'zarmumia-lift' ), __( 'Browsers show "Not secure", which scares visitors away, and search engines prefer secure sites.', 'zarmumia-lift' ), __( 'Ask your hosting company to turn on a free SSL certificate and send all visitors to https.', 'zarmumia-lift' ), '' ),
			'schema'         => array( 'business', __( 'Your business details are in the page code', 'zarmumia-lift' ), __( 'Your business details are not in the page code', 'zarmumia-lift' ), __( 'Engines read a hidden summary of who you are. Without it they have to guess.', 'zarmumia-lift' ), __( 'Turn on business details in Lift.', 'zarmumia-lift' ), Admin::pro_link( Admin::SCHEMA_SLUG ) ),
			'details'        => array( 'business', __( 'Founder, area, address and languages are included', 'zarmumia-lift' ), __( 'Founder, area, address or languages are missing', 'zarmumia-lift' ), __( 'These details help engines connect you to questions like "who does X in my city".', 'zarmumia-lift' ), __( 'Fill them in Lift\'s short questions and turn on business details.', 'zarmumia-lift' ), Wizard::url( 'people' ) ),
			'phone'          => array( 'business', __( 'Your phone number matches your page', 'zarmumia-lift' ), __( 'Your phone number is missing, or does not appear on your page', 'zarmumia-lift' ), __( 'The same name, address and phone everywhere (site, Google, social) builds trust with engines.', 'zarmumia-lift' ), __( 'Add your phone in Lift\'s questions, the same number that appears on your page and on Google.', 'zarmumia-lift' ), Wizard::url( 'people' ) ),
			'google_profile' => array( 'business', __( 'Your Google Business Profile is linked', 'zarmumia-lift' ), __( 'Your Google Business Profile is not linked', 'zarmumia-lift' ), __( 'The link tells Google that your site and your business on Google Maps are the same business.', 'zarmumia-lift' ), __( 'Paste the link in Lift\'s questions, in the links step.', 'zarmumia-lift' ), Wizard::url( 'links' ) ),
			'sitemap'        => array( 'business', __( 'Your site has a sitemap', 'zarmumia-lift' ), __( 'No sitemap was found', 'zarmumia-lift' ), __( 'A sitemap helps crawlers find all your pages.', 'zarmumia-lift' ), __( 'See the details in Lift.', 'zarmumia-lift' ), Admin::pro_link( Admin::CRAWLERS_SLUG ) ),
			'title'          => array( 'content', __( 'Your home page has a title', 'zarmumia-lift' ), __( 'Your home page has no title', 'zarmumia-lift' ), __( 'The title is the first line people see in search results.', 'zarmumia-lift' ), __( 'Set it in your SEO plugin, or in Settings → General.', 'zarmumia-lift' ), '' ),
			'description'    => array( 'content', __( 'Your home page has a description for search', 'zarmumia-lift' ), __( 'Your home page has no description for search', 'zarmumia-lift' ), __( 'Without one, search engines pick a random sentence from your page.', 'zarmumia-lift' ), __( 'In your SEO plugin, open the home page and write one or two sentences about what you do and for whom.', 'zarmumia-lift' ), '' ),
			'h1'             => array( 'content', __( 'Your home page has one main heading', 'zarmumia-lift' ), __( 'Your home page should have exactly one main heading', 'zarmumia-lift' ), __( 'One main heading (H1) tells engines what the page is about. Found: %s.', 'zarmumia-lift' ), __( 'In your page editor, keep one heading as "H1" and change the others to "H2".', 'zarmumia-lift' ), '' ),
			'h2'             => array( 'content', __( 'Your page is divided into sections with headings', 'zarmumia-lift' ), __( 'Your page has no section headings', 'zarmumia-lift' ), __( 'Section headings (H2) help engines understand the parts of your page.', 'zarmumia-lift' ), __( 'Give each section of the page a short heading.', 'zarmumia-lift' ), '' ),
			'alt'            => array( 'content', __( 'All images have a description', 'zarmumia-lift' ), __( 'Some images have no description', 'zarmumia-lift' ), __( 'Engines cannot see images; they read a short description (alt text). Missing: %1$s of %2$s images.', 'zarmumia-lift' ), __( 'In the editor, click each image and write in one sentence what it shows.', 'zarmumia-lift' ), '' ),
			'lang'           => array( 'content', __( 'Your page is marked with the right language and direction', 'zarmumia-lift' ), __( 'Your page language or direction is not marked correctly', 'zarmumia-lift' ), __( 'The marking tells engines which language they are reading.', 'zarmumia-lift' ), __( 'Check Settings → General → Site language. If it is right, ask whoever built the theme.', 'zarmumia-lift' ), '' ),
			'llms'           => array( 'ai', __( 'Your site has llms.txt', 'zarmumia-lift' ), __( 'Your site has no llms.txt', 'zarmumia-lift' ), __( 'A new, optional summary file for AI engines. Few of them read it today, so it counts little.', 'zarmumia-lift' ), __( 'Publish it in Lift.', 'zarmumia-lift' ), $lift( Llms::PAGE_SLUG ) ),
			'faq'            => array( 'ai', __( 'Your questions and answers are marked for engines', 'zarmumia-lift' ), __( 'No marked questions and answers', 'zarmumia-lift' ), __( 'Questions your clients ask, with short answers, are easy for AI engines to quote.', 'zarmumia-lift' ), __( 'Add a few questions to your page (a heading ending with "?" and a short answer), then turn on business details in Lift.', 'zarmumia-lift' ), Admin::pro_link( Admin::SCHEMA_SLUG ) ),
			'weight'         => array( 'info', __( 'Your home page is not heavy', 'zarmumia-lift' ), __( 'Your home page is heavy', 'zarmumia-lift' ), __( 'Size of the page code: %s MB. Heavy pages load slowly, especially on phones.', 'zarmumia-lift' ), __( 'Ask whoever built the site to compress images and remove unused add-ons.', 'zarmumia-lift' ), '' ),
			'accessibility'  => array( 'info', __( 'No accessibility widget was found', 'zarmumia-lift' ), __( 'An accessibility widget was found', 'zarmumia-lift' ), __( 'Found: %s. It is often required by law, so Lift never touches it. Some widgets slow the page down.', 'zarmumia-lift' ), __( 'Nothing to do. If the page is slow, ask your accessibility provider about a lighter setup.', 'zarmumia-lift' ), '' ),
			'slugs'          => array( 'info', __( 'Your page addresses are readable', 'zarmumia-lift' ), __( 'Some page addresses use non-Latin letters', 'zarmumia-lift' ), __( 'When shared, they turn into long codes like %%D7%%A9... (%s pages). It is not an error.', 'zarmumia-lift' ), __( 'Only for new pages: choose a short English address. Changing an existing address breaks links to it, so do not change it without a redirect.', 'zarmumia-lift' ), '' ),
		);
		if ( ! $home ) {
			// Another page than the home page: the same checks, worded for "this page".
			$other = array(
				'noindex'     => array( __( 'This page can appear in search', 'zarmumia-lift' ), __( 'This page is marked "do not show in search"', 'zarmumia-lift' ), 4 => __( 'In your SEO plugin, open this page\'s settings and allow it to appear in search results.', 'zarmumia-lift' ) ),
				'canonical'   => array( __( 'This page points to itself as the main version', 'zarmumia-lift' ), __( 'This page points to a different address as the main version', 'zarmumia-lift' ), 4 => __( 'Ask whoever built your site to check the "canonical" setting of this page.', 'zarmumia-lift' ) ),
				'title'       => array( __( 'This page has a title', 'zarmumia-lift' ), __( 'This page has no title', 'zarmumia-lift' ), 4 => __( 'Set it in your SEO plugin, or give the page a name in the page editor.', 'zarmumia-lift' ) ),
				'description' => array( __( 'This page has a description for search', 'zarmumia-lift' ), __( 'This page has no description for search', 'zarmumia-lift' ), 4 => __( 'In your SEO plugin, open this page and write one or two sentences about what you do and for whom.', 'zarmumia-lift' ) ),
				'h1'          => array( __( 'This page has one main heading', 'zarmumia-lift' ), __( 'This page should have exactly one main heading', 'zarmumia-lift' ) ),
				'weight'      => array( __( 'This page is not heavy', 'zarmumia-lift' ), __( 'This page is heavy', 'zarmumia-lift' ) ),
			);
			foreach ( $other as $key => $words ) {
				$t[ $key ][1] = $words[0];
				$t[ $key ][2] = $words[1];
				if ( isset( $words[4] ) ) {
					$t[ $key ][4] = $words[4];
				}
			}
		}
		$row = $t[ $id ];
		if ( $data && false !== strpos( $row[3], '%' ) ) {
			$row[3] = vsprintf( $row[3], array_map( 'strval', $data ) );
		}
		return array_combine( array( 'group', 'title_pass', 'title_fail', 'meaning', 'fix', 'link' ), $row );
	}

	/**
	 * Score and list.
	 *
	 * @param array $scan Saved scan.
	 */
	public static function render_results( array $scan ) {
		$score   = (int) $scan['score'];
		$class   = $score >= 80 ? 'good' : ( $score >= 50 ? 'ok' : 'low' );
		$weights = self::weights();
		$groups  = array(
			'access'   => __( 'Access for engines', 'zarmumia-lift' ),
			'business' => __( 'Business details', 'zarmumia-lift' ),
			'content'  => __( 'Page content', 'zarmumia-lift' ),
			'ai'       => __( 'AI extras', 'zarmumia-lift' ),
			'info'     => __( 'Good to know (no points)', 'zarmumia-lift' ),
		);
		$page_id  = (int) ( $scan['page'] ?? 0 );
		$home     = self::is_home( $page_id );
		$fixable  = ZARMUMIA_LIFT_PRO && $page_id && Page_Fixes::allowed( $page_id ); // Show "Fixes for this page".
		$by_group = array();
		foreach ( $scan['checks'] as $id => $check ) {
			$text                         = self::texts( $id, (array) $check[1], $home );
			$by_group[ $text['group'] ][] = array( $id, $check[0], $text );
		}
		$fixes = 0;
		foreach ( $scan['checks'] as $id => $check ) {
			if ( isset( $weights[ $id ] ) && 'pass' !== $check[0] ) {
				$fixes++;
			}
		}
		?>
		<div class="zarmumia-lift-score zarmumia-lift-score--<?php echo esc_attr( $class ); ?>">
			<div class="zarmumia-lift-score__num"><?php echo esc_html( number_format_i18n( $score ) ); ?></div>
			<div>
				<strong><?php esc_html_e( 'Your AI readiness score', 'zarmumia-lift' ); ?></strong>
				<?php if ( $page_id && ! $home ) : ?>
					<?php /* translators: %s: page title. */ ?>
					<p class="zarmumia-lift-checked-page"><?php echo esc_html( sprintf( __( 'Page: %s', 'zarmumia-lift' ), get_the_title( $page_id ) ) ); ?></p>
				<?php endif; ?>
				<p>
					<?php
					echo esc_html(
						$fixes
							/* translators: %s: number of things to fix. */
							? sprintf( _n( '%s thing to fix. Each one is explained below in plain words.', '%s things to fix. Each one is explained below in plain words.', $fixes, 'zarmumia-lift' ), number_format_i18n( $fixes ) )
							: __( 'Everything Lift checks is in place.', 'zarmumia-lift' )
					);
					?>
				</p>
				<p class="zarmumia-lift-muted">
					<?php
					/* translators: %s: date and time of the last check. */
					echo esc_html( sprintf( __( 'Checked: %s. "Ready to be read by AI engines" does not guarantee you will appear in their answers.', 'zarmumia-lift' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $scan['time'] ) ) );
					?>
				</p>
			</div>
		</div>

		<?php foreach ( $groups as $key => $label ) : ?>
			<?php
			if ( empty( $by_group[ $key ] ) ) {
				continue;
			}
			// Problems first.
			usort( $by_group[ $key ], function ( $a, $b ) { return ( 'pass' === $a[1] ) <=> ( 'pass' === $b[1] ); } );
			?>
			<h3><?php echo esc_html( $label ); ?></h3>
			<ul class="zarmumia-lift-checks">
				<?php foreach ( $by_group[ $key ] as list( $id, $status, $text ) ) : ?>
					<li class="is-<?php echo esc_attr( $status ); ?>">
						<span class="zarmumia-lift-dot"></span>
						<div>
							<strong><?php echo esc_html( 'pass' === $status ? $text['title_pass'] : $text['title_fail'] ); ?></strong>
							<?php if ( 'pass' !== $status ) : ?>
								<p><?php echo esc_html( $text['meaning'] ); ?></p>
								<p><strong><?php esc_html_e( 'How to fix:', 'zarmumia-lift' ); ?></strong> <?php echo esc_html( $text['fix'] ); ?>
									<?php if ( ! ZARMUMIA_LIFT_PRO && in_array( $id, self::PRO_FIXES, true ) ) : ?>
										<?php Admin::pro_tag(); ?>
									<?php elseif ( $fixable && in_array( $id, Page_Fixes::FIX_IDS, true ) ) : ?>
										<a href="#<?php echo esc_attr( Page_Fixes::ANCHOR ); ?>"><?php esc_html_e( 'Fix it below, in Lift', 'zarmumia-lift' ); ?></a>
									<?php elseif ( $text['link'] ) : ?>
										<a href="<?php echo esc_url( $text['link'] ); ?>"><?php esc_html_e( 'Go there', 'zarmumia-lift' ); ?></a>
									<?php endif; ?>
								</p>
							<?php endif; ?>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endforeach; ?>
		<?php
		if ( $fixable ) {
			Page_Fixes::render_panel( $page_id, $scan );
		} elseif ( ! ZARMUMIA_LIFT_PRO ) {
			?>
			<div class="zarmumia-lift-fixes">
				<h2><?php esc_html_e( 'Fixes for this page', 'zarmumia-lift' ); ?> <?php Admin::pro_tag(); ?></h2>
				<p class="zarmumia-lift-muted"><?php esc_html_e( 'Description for Google, image descriptions, main heading, and questions and answers: Lift helps you fix them step by step.', 'zarmumia-lift' ); ?></p>
			</div>
			<?php
		}
	}

	/**
	 * The screen. The script runs the check on load and when the button is clicked.
	 */
	public static function render() {
		if ( ! current_user_can( Admin::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'zarmumia-lift' ) );
		}
		$id   = self::target();
		$home = self::is_home( $id );
		$scan = self::saved( $id );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only flag after redirect.
		$notice = isset( $_GET['lift'] ) ? sanitize_key( wp_unslash( $_GET['lift'] ) ) : '';
		$auto   = ! is_array( $scan ) || '' !== $notice; // Check again after a fix.
		?>
		<div class="wrap zarmumia-lift">
			<h1><?php esc_html_e( 'Your AI readiness', 'zarmumia-lift' ); ?></h1>
			<?php
			if ( ZARMUMIA_LIFT_PRO ) {
				Page_Fixes::render_notice( $notice );
			}
			?>
			<div class="zarmumia-lift-card">
				<?php
				if ( ZARMUMIA_LIFT_SITE ) {
					Site_Pages::render_switch( $id );
				} elseif ( ZARMUMIA_LIFT_PRO ) {
					Page_Fixes::render_choice();
				}
				?>
				<p>
					<?php
					echo esc_html(
						$home
							? __( 'Lift checks your home page the way a visitor and a search engine see it. It only reports; it changes nothing.', 'zarmumia-lift' )
							: __( 'Lift checks this page the way a visitor and a search engine see it. The check itself changes nothing.', 'zarmumia-lift' )
					);
					?>
				</p>
				<p><button type="button" class="button button-primary" id="zarmumia-lift-rescan"><?php esc_html_e( 'Check again', 'zarmumia-lift' ); ?></button> <span class="zarmumia-lift-muted" id="zarmumia-lift-scan-status"></span></p>
				<div id="zarmumia-lift-results" data-auto="<?php echo $auto ? '1' : '0'; ?>">
					<?php
					if ( is_array( $scan ) ) {
						self::render_results( $scan );
					} else {
						echo '<p>' . esc_html( $home ? __( 'Checking your home page…', 'zarmumia-lift' ) : __( 'Checking this page…', 'zarmumia-lift' ) ) . '</p>';
					}
					?>
				</div>
			</div>
			<?php
			if ( ZARMUMIA_LIFT_SITE ) {
				Site_Pages::render_table( $id );
			} elseif ( ZARMUMIA_LIFT_PRO ) {
				?>
				<div class="zarmumia-lift-card">
					<h2><?php esc_html_e( 'All your pages', 'zarmumia-lift' ); ?> <?php Admin::site_tag(); ?></h2>
					<p class="zarmumia-lift-muted"><?php esc_html_e( 'A check and fixes for every page on your site: services, about, contact and more.', 'zarmumia-lift' ); ?></p>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	}
}
