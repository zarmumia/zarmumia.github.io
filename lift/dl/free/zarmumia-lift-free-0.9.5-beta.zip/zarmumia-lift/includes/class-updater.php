<?php
/**
 * Update by click (decided 9.11.2026): WordPress shows "There is a new version of Lift" and updates in one click.
 *
 * How: once in a while Lift reads a small public file on zarmumia.co.il with the latest version number.
 * Nothing about the site is sent: not its address, not its content (a plain user agent, no site URL).
 * The download address of each paid package is written only inside that package's own files
 * (includes/pro, includes/site), so the free version does not know it ("secret address per package").
 *
 * @package ZarmumiaLift
 */

namespace ZarmumiaLift;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Updates from zarmumia.co.il.
 */
class Updater {

	const SLUG      = 'zarmumia-lift';
	const CACHE     = 'zarmumia_lift_update_info'; // Transient (removed on uninstall with the other zarmumia_lift_ data).
	const CACHE_TTL = 43200;                         // 12 hours.

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'add_update' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'details' ), 20, 3 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'clear_cache' ), 10, 0 );
	}

	/**
	 * Where updates come from. A test site may point elsewhere by defining ZARMUMIA_LIFT_UPDATE_BASE.
	 *
	 * @return string
	 */
	private static function base() {
		return defined( 'ZARMUMIA_LIFT_UPDATE_BASE' ) ? untrailingslashit( ZARMUMIA_LIFT_UPDATE_BASE ) : 'https://zarmumia.co.il';
	}

	/**
	 * This copy's package: free, landing or site.
	 *
	 * @return string
	 */
	public static function edition() {
		return ZARMUMIA_LIFT_SITE ? 'site' : ( ZARMUMIA_LIFT_PRO ? 'landing' : 'free' );
	}

	/**
	 * Download folder of this package. The paid ones come from the paid files themselves.
	 *
	 * @return string
	 */
	private static function folder() {
		if ( ZARMUMIA_LIFT_SITE ) {
			return Site_Pages::DOWNLOADS;
		}
		if ( ZARMUMIA_LIFT_PRO ) {
			return Page_Fixes::DOWNLOADS;
		}
		return 'free';
	}

	/**
	 * Latest version info from zarmumia.co.il (cached). Sends nothing about this site.
	 *
	 * @return array|null { version, requires, requires_php, tested, changelog }
	 */
	public static function info() {
		$cached = get_site_transient( self::CACHE );
		if ( is_array( $cached ) ) {
			return $cached ? $cached : null;
		}
		$response = wp_remote_get(
			self::base() . '/lift/update/version.json',
			array(
				'timeout'    => 8,
				'user-agent' => 'Lift-by-Zarmumia-updater', // No site address, unlike WordPress's default.
				'headers'    => array( 'Accept' => 'application/json' ),
			)
		);
		$data = null;
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			$json = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( is_array( $json ) && ! empty( $json['version'] ) && preg_match( '/^[0-9][0-9a-z.\-]*$/i', (string) $json['version'] ) ) {
				$data = array(
					'version'      => (string) $json['version'],
					'requires'     => (string) ( $json['requires'] ?? '' ),
					'requires_php' => (string) ( $json['requires_php'] ?? '' ),
					'tested'       => (string) ( $json['tested'] ?? '' ),
					'changelog'    => array_map( 'strval', (array) ( $json['changelog'] ?? array() ) ),
				);
			}
		}
		// Remember failures too (as an empty array), so a site never asks more than twice a day.
		set_site_transient( self::CACHE, $data ? $data : array(), self::CACHE_TTL );
		return $data;
	}

	/**
	 * Download address of a version of this package.
	 *
	 * @param string $version Version.
	 * @return string
	 */
	private static function package_url( $version ) {
		return self::base() . '/lift/dl/' . self::folder() . '/zarmumia-lift-' . self::edition() . '-' . rawurlencode( $version ) . '.zip';
	}

	/**
	 * Tell WordPress when a newer version exists.
	 *
	 * @param object $transient Update data.
	 * @return object
	 */
	public static function add_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$info = self::info();
		$file = plugin_basename( ZARMUMIA_LIFT_FILE );
		$item = (object) array(
			'id'           => 'zarmumia.co.il/lift',
			'slug'         => self::SLUG,
			'plugin'       => $file,
			'new_version'  => $info ? $info['version'] : ZARMUMIA_LIFT_VERSION,
			'url'          => 'https://zarmumia.co.il/lift/',
			'package'      => $info ? self::package_url( $info['version'] ) : '',
			'requires'     => $info ? $info['requires'] : '',
			'requires_php' => $info ? $info['requires_php'] : '',
			'tested'       => $info ? $info['tested'] : '',
			'icons'        => array( 'default' => ZARMUMIA_LIFT_URL . 'assets/gecko_teal.png' ),
		);
		if ( $info && version_compare( $info['version'], ZARMUMIA_LIFT_VERSION, '>' ) ) {
			$transient->response[ $file ] = $item;
		} else {
			$transient->no_update[ $file ] = $item; // Also enables the "auto-updates" link for Lift.
		}
		return $transient;
	}

	/**
	 * "View details" window for Lift.
	 *
	 * @param false|object|array $result Result.
	 * @param string             $action Action.
	 * @param object             $args   Arguments.
	 * @return false|object|array
	 */
	public static function details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
			return $result;
		}
		$info = self::info();
		if ( ! $info ) {
			return $result;
		}
		$changes = '<ul>';
		foreach ( $info['changelog'] as $line ) {
			$changes .= '<li>' . esc_html( $line ) . '</li>';
		}
		$changes .= '</ul>';
		return (object) array(
			'name'          => 'Lift by Zarmumia',
			'slug'          => self::SLUG,
			'version'       => $info['version'],
			'author'        => '<a href="https://zarmumia.co.il/">Zarmumia</a>',
			'homepage'      => 'https://zarmumia.co.il/lift/',
			'requires'      => $info['requires'],
			'requires_php'  => $info['requires_php'],
			'tested'        => $info['tested'],
			'download_link' => self::package_url( $info['version'] ),
			'sections'      => array(
				'description' => esc_html__( 'Makes a working landing page ready to be read by AI engines, without changing its design or content.', 'zarmumia-lift' ),
				'changelog'   => $changes,
			),
		);
	}

	/**
	 * After an update, check again next time instead of using the old answer.
	 */
	public static function clear_cache() {
		delete_site_transient( self::CACHE );
	}
}
