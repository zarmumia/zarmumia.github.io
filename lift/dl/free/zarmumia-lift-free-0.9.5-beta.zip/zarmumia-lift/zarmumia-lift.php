<?php
/**
 * Plugin Name:       Lift by Zarmumia
 * Description:       Makes a working landing page ready to be read by AI engines, without changing its design or content.
 * Version:           0.9.5-beta
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Zarmumia
 * Author URI:        https://zarmumia.co.il/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       zarmumia-lift
 * Domain Path:       /languages
 *
 * @package ZarmumiaLift
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ZARMUMIA_LIFT_VERSION', '0.9.5-beta' );
define( 'ZARMUMIA_LIFT_FILE', __FILE__ );
define( 'ZARMUMIA_LIFT_DIR', plugin_dir_path( __FILE__ ) );
define( 'ZARMUMIA_LIFT_URL', plugin_dir_url( __FILE__ ) );

/**
 * Every option this plugin stores starts with this prefix, so uninstall can remove them all.
 */
define( 'ZARMUMIA_LIFT_OPTION_PREFIX', 'zarmumia_lift_' );

/**
 * Full or free version. The free download simply does not include the "includes/pro" folder
 * (business details for search engines, crawlers and sitemap), so it has none of that code.
 * Upgrading = uploading the full version over the free one; all answers and llms.txt are kept.
 */
define( 'ZARMUMIA_LIFT_PRO', file_exists( ZARMUMIA_LIFT_DIR . 'includes/pro/class-schema.php' ) );

/**
 * Paid packages (decided 9.11.2026): "Landing page" = the full version, with page fixes for ONE page.
 * "Whole site" = the same, plus the "includes/site" folder: page fixes for every page and the all-pages table.
 * The landing-page download simply does not include "includes/site".
 */
define( 'ZARMUMIA_LIFT_SITE', ZARMUMIA_LIFT_PRO && file_exists( ZARMUMIA_LIFT_DIR . 'includes/site/class-site-pages.php' ) );

/**
 * Where "In the full version" and "In the Whole site package" links go: the packages on the Lift page.
 */
define( 'ZARMUMIA_LIFT_UPGRADE_URL', 'https://zarmumia.co.il/lift/#pkgs' );

require_once ZARMUMIA_LIFT_DIR . 'includes/class-business.php';
require_once ZARMUMIA_LIFT_DIR . 'includes/class-wizard.php';
require_once ZARMUMIA_LIFT_DIR . 'includes/class-llms.php';
require_once ZARMUMIA_LIFT_DIR . 'includes/class-robots.php';
require_once ZARMUMIA_LIFT_DIR . 'includes/class-readiness.php';
require_once ZARMUMIA_LIFT_DIR . 'includes/class-admin.php';
require_once ZARMUMIA_LIFT_DIR . 'includes/class-updater.php';

ZarmumiaLift\Llms::init();
ZarmumiaLift\Updater::init();

if ( ZARMUMIA_LIFT_PRO ) {
	require_once ZARMUMIA_LIFT_DIR . 'includes/pro/class-schema.php';
	require_once ZARMUMIA_LIFT_DIR . 'includes/pro/class-crawlers.php';
	require_once ZARMUMIA_LIFT_DIR . 'includes/pro/class-page-fixes.php';
	if ( ZARMUMIA_LIFT_SITE ) {
		require_once ZARMUMIA_LIFT_DIR . 'includes/site/class-site-pages.php';
	}
	ZarmumiaLift\Crawlers::init();
	ZarmumiaLift\Page_Fixes::init();
	add_action( 'plugins_loaded', array( 'ZarmumiaLift\Schema', 'init' ) ); // After SEO plugins have loaded.
}

/**
 * Load translations (Hebrew and others) from the plugin's languages folder.
 */
function zarmumia_lift_load_textdomain() {
	load_plugin_textdomain( 'zarmumia-lift', false, dirname( plugin_basename( ZARMUMIA_LIFT_FILE ) ) . '/languages' ); // Hebrew ships with the plugin (decided 9.11.2026).
}
add_action( 'init', 'zarmumia_lift_load_textdomain' );

/**
 * Activation: only records the installed version. Nothing on the site is changed.
 */
function zarmumia_lift_activate() {
	add_option( ZARMUMIA_LIFT_OPTION_PREFIX . 'version', ZARMUMIA_LIFT_VERSION, '', false );
}
register_activation_hook( __FILE__, 'zarmumia_lift_activate' );

/**
 * Deactivation: nothing to undo yet. Data is kept until the plugin is deleted (see uninstall.php).
 */
function zarmumia_lift_deactivate() {}
register_deactivation_hook( __FILE__, 'zarmumia_lift_deactivate' );

if ( is_admin() ) {
	ZarmumiaLift\Admin::init();
	ZarmumiaLift\Wizard::init();
	ZarmumiaLift\Readiness::init();
}
